<template>
  <div class="action-menu-panel">
    <!-- 当前处境 -->
    <div v-if="store.当前处境" class="situation-section">
      <div class="section-title">
        <i class="fa-solid fa-compass"></i> 当前处境
      </div>
      <div class="situation-content">
        {{ formatThirdPerson(store.当前处境) }}
      </div>
    </div>

    <!-- 可选行动列表 -->
    <div class="actions-section">
      <div class="section-title">
        <div class="title-left">
          <i class="fa-solid fa-list-check"></i> 可选行动
        </div>
        <div class="title-right">
          <button class="toggle-btn" :class="{ active: store.启用行动提示 }" :title="store.启用行动提示 ? '关闭行动提示生成' : '开启行动提示生成'" @click="store.toggleActionPrompt">
            <i class="fa-solid" :class="store.启用行动提示 ? 'fa-toggle-on' : 'fa-toggle-off'"></i>
            <span>{{ store.启用行动提示 ? '已开启' : '已关闭' }}</span>
          </button>
          <button v-if="store.启用行动提示" class="refresh-btn" title="刷新行动列表" @click="refreshActions">
            <i class="fa-solid fa-rotate-right" :class="{ 'fa-spin': isRefreshing }"></i>
          </button>
          <span v-if="store.启用行动提示" class="action-count">{{ store.可参与机遇.length }} 项机遇</span>
        </div>
      </div>

      <!-- 关闭提示 -->
      <div v-if="!store.启用行动提示" class="no-actions disabled-state">
        <i class="fa-solid fa-power-off"></i>
        <p>行动提示已关闭</p>
        <p class="hint">AI 将不再生成行动选项以节省 Token</p>
      </div>

      <!-- 无行动提示 -->
      <div v-else-if="store.可参与机遇.length === 0" class="no-actions">
        <i class="fa-solid fa-hourglass-half"></i>
        <p>暂无明确的行动机遇</p>
        <p class="hint">可选择「随缘而行」探索周围</p>
      </div>

      <!-- 行动卡片列表 -->
      <div v-else class="action-list">
        <div
          v-for="(action, index) in sortedActions"
          :key="getActionKey(action, index)"
          class="action-card"
          :class="[
            `type-${action.类型}`,
            { urgent: action.时限 },
            detectNsfwSubType(action) ? `nsfw-${detectNsfwSubType(action)}` : '',
          ]"
          @click="selectAction(action)"
        >
          <!-- 行动类型图标（NSFW 子类使用专属图标和样式） -->
          <div class="action-icon" :class="detectNsfwSubType(action) ? `icon-nsfw-${detectNsfwSubType(action)}` : `icon-${action.类型}`">
            <i :class="getActionIcon(action.类型, detectNsfwSubType(action))"></i>
          </div>

          <!-- 行动信息 -->
          <div class="action-info">
            <div class="action-header">
              <span class="action-name">{{ action.名称 }}</span>
              <span class="action-type-tag" :class="detectNsfwSubType(action) ? `tag-nsfw-${detectNsfwSubType(action)}` : ''">
                {{ detectNsfwSubType(action) ? `红颜·${detectNsfwSubType(action)}` : action.类型 }}
              </span>
            </div>

            <div v-if="action.来源" class="action-source">
              <i class="fa-solid fa-location-dot"></i> {{ action.来源 }}
            </div>

            <div class="action-desc">{{ formatThirdPerson(action.描述) }}</div>

            <!-- 回报与风险 -->
            <div class="action-meta">
              <div v-if="action.回报预期" class="reward">
                <i class="fa-solid fa-gift"></i>
                <span>{{ formatThirdPerson(action.回报预期) }}</span>
              </div>
              <div v-if="action.风险评估 && !['无', '无风险', ''].includes(action.风险评估.trim())" class="risk">
                <i class="fa-solid fa-skull"></i>
                <span>{{ formatThirdPerson(action.风险评估) }}</span>
              </div>
            </div>

            <!-- 时限警告 -->
            <div v-if="action.时限" class="time-limit">
              <i class="fa-solid fa-clock"></i>
              <span>{{ action.时限 }}</span>
            </div>
          </div>

          <!-- 优先级标记 -->
          <div class="priority-indicator" :class="`priority-${action.优先级}`">
            <span v-for="n in action.优先级" :key="n">★</span>
          </div>
        </div>
      </div>

      <!-- 常驻选项区域 -->
      <div v-if="store.启用行动提示" class="permanent-actions">
        <!-- 顺势而为（推剧情） -->
        <div class="action-card story-action" @click="selectStoryAction">
          <div class="action-icon icon-剧情">
            <i class="fa-solid fa-book-open"></i>
          </div>
          <div class="action-info">
            <div class="action-header">
              <span class="action-name">📖 顺势而为</span>
              <span class="action-type-tag">推进</span>
            </div>
            <div class="action-desc">顺应当前局势发展，自然地推进下一步剧情，不刻意节外生枝。</div>
            <div class="action-meta">
              <div class="reward">
                <i class="fa-solid fa-forward-step"></i>
                <span>剧情发展</span>
              </div>
            </div>
          </div>
        </div>

        <!-- 随缘而行选项 -->
        <div class="action-card random-action" @click="selectRandomAction">
          <div class="action-icon icon-随机">
            <i class="fa-solid fa-dice"></i>
          </div>
          <div class="action-info">
            <div class="action-header">
              <span class="action-name">🎲 随缘而行</span>
              <span class="action-type-tag">随机</span>
            </div>
            <div class="action-desc">不做具体选择，随遇而安地探索周围，或许会有意外收获...</div>
            <div class="action-meta">
              <div class="reward">
                <i class="fa-solid fa-gift"></i>
                <span>未知机遇</span>
              </div>
              <div class="risk">
                <i class="fa-solid fa-skull"></i>
                <span>不确定</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useDataStore } from '../store';

const store = useDataStore();
const isRefreshing = ref(false);

// 刷新行动列表
const refreshActions = async () => {
  if (isRefreshing.value) return;
  
  isRefreshing.value = true;
  try {
    // 调用 store 中的强制刷新方法
    if (store.forceRefresh) {
      await store.forceRefresh();
      // toastr.success('行动列表已刷新', '行动提示'); // 用户反馈太烦了
    } else {
      // 回退方案：仅刷新数据
      store.refresh();
      // toastr.info('数据已重新加载', '行动提示'); // 用户反馈太烦了
    }
  } catch (e) {
    console.error('刷新行动列表失败', e);
    // 失败时还是提示一下比较好
    toastr.error('刷新失败', '行动提示');
  } finally {
    // 延迟一点结束动画，让用户感知到刷新过程
    setTimeout(() => {
      isRefreshing.value = false;
    }, 500);
  }
};

// 组件挂载时自动刷新一次，确保数据最新
onMounted(() => {
  // 延迟一点执行，避免与页面初始化冲突
  setTimeout(() => {
    refreshActions();
  }, 500);
});

// NSFW 子类检测：根据名称/描述关键词识别红颜类行动的 NSFW 子分类
type NsfwSubType = '双修' | '亲密' | '调情' | null;
const detectNsfwSubType = (action: { 名称: string; 描述: string; 类型: string }): NsfwSubType => {
  if (action.类型 !== '红颜') return null;
  const text = `${action.名称}${action.描述}`;
  // 双修关键词（修炼相关的亲密行为）
  if (/双修|阴阳交泰|合欢|采补|鼎炉|双生|交融|合道|合炉|共修|双运|欢好/.test(text)) return '双修';
  // 亲密关键词（身体接触、深度互动）
  if (/亲密|缠绵|温存|相拥|依偎|温养|抚慰|肌肤|贴身|共寝|同眠|入帐|春宵|云雨|巫山/.test(text)) return '亲密';
  // 调情关键词（语言/轻度互动）
  if (/调情|挑逗|撩拨|暧昧|情话|戏弄|勾引|媚眼|风情|轻薄|调戏|嬉闹/.test(text)) return '调情';
  return null;
};

// 行动类型图标映射（支持 NSFW 子类覆盖）
const getActionIcon = (type: string, nsfwSub?: NsfwSubType): string => {
  // NSFW 子类优先使用专属图标
  if (nsfwSub) {
    const nsfwIconMap: Record<string, string> = {
      双修: 'fa-solid fa-fire',
      亲密: 'fa-solid fa-hand-holding-heart',
      调情: 'fa-solid fa-kiss-wink-heart',
    };
    return nsfwIconMap[nsfwSub] || 'fa-solid fa-heart';
  }
  const iconMap: Record<string, string> = {
    探索: 'fa-solid fa-mountain-sun',
    任务: 'fa-solid fa-scroll',
    交易: 'fa-solid fa-coins',
    结交: 'fa-solid fa-handshake',
    争夺: 'fa-solid fa-swords',
    修炼: 'fa-solid fa-yin-yang',
    红颜: 'fa-solid fa-heart',
    随机: 'fa-solid fa-dice',
  };
  return iconMap[type] || 'fa-solid fa-question';
};

// 按优先级排序的行动列表
const sortedActions = computed(() => {
  return [...store.可参与机遇].sort((a, b) => {
    // 有时限的优先
    if (a.时限 && !b.时限) return -1;
    if (!a.时限 && b.时限) return 1;
    // 然后按优先级排序
    return (b.优先级 || 3) - (a.优先级 || 3);
  });
});

const getActionKey = (action: unknown, index: number): string => {
  return `${JSON.stringify(action)}|${index}`;
};

// 发送消息到酒馆输入框
const sendToInput = (text: string) => {
  // 前端界面运行在 iframe 中，需要使用 window.parent.$ 访问酒馆主页面的 DOM
  const parent$ = (window.parent as typeof window & { $: typeof $ }).$;
  const $textarea = parent$('#send_textarea');
  if ($textarea.length) {
    const textarea = $textarea[0] as HTMLTextAreaElement | undefined;
    if (!textarea) return;
    // 1) 直接写入原生 value，确保与酒馆监听链一致
    textarea.value = text;

    // 2) 触发原生事件（酒馆输入框高度自适应通常挂在这些事件上）
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
    textarea.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: ' ' }));

    // 3) 兼容 jQuery 监听器
    $textarea.trigger('input');
    $textarea.trigger('change');

    // 4) 双保险：手动重算高度，避免程序注入文本时未触发自动拉高
    textarea.style.height = 'auto';
    textarea.style.height = `${textarea.scrollHeight}px`;

    // 5) 发送后酒馆通常会清空输入框；检测到清空后恢复高度为 auto
    // 说明：部分主题/插件不会触发标准 input 事件，所以这里做短时轮询兜底
    let retry = 0;
    const maxRetry = 20; // 最长约 6 秒
    const restoreHeightWhenCleared = () => {
      if (!textarea.value) {
        // 仅恢复为主题默认高度，不再额外触发 input，避免回缩时二次抖动
        textarea.style.height = '';
        return;
      }
      retry += 1;
      if (retry < maxRetry) {
        window.setTimeout(restoreHeightWhenCleared, 300);
      }
    };
    window.setTimeout(restoreHeightWhenCleared, 300);

    // 聚焦输入框
    textarea.focus();
    console.info('[行动提示] 已发送到输入框:', text);
    toastr.success('已添加到输入框', '行动选择');
  } else {
    console.warn('[行动提示] 未找到输入框');
    toastr.warning('未找到输入框', '行动选择');
  }
};

// 从候选池中随机选一个
const pick = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

// 辅助函数：移除字符串末尾的标点符号
const trimPunctuation = (str: string) => {
  return str.replace(/[，。！？；：、,.!?;:]+$/, '').trim();
};

// 获取玩家名字
const getUserName = () => {
  try {
    // 尝试从酒馆全局变量中获取玩家名字
    const name = SillyTavern.name1;
    return name || '本尊';
  } catch (e) {
    console.warn('[行动提示] 获取玩家名字失败，回退到默认称呼', e);
    return '本尊';
  }
};

// 转换为第三人称
const formatThirdPerson = (text: string) => {
  if (!text) return '';
  const userName = getUserName();
  return text.replace(/你/g, userName);
};

// 选择行动
const selectAction = (action: (typeof store.可参与机遇)[number]) => {
  let actionText = '';
  const userName = getUserName();

  // 1. 引入当前处境作为前置铺垫（如果有），增加代入感
  if (store.当前处境) {
    const situation = formatThirdPerson(store.当前处境);
    actionText += `眼下${trimPunctuation(situation)}，`;
  }

  // 2. 核心行动描述（融合名称和描述）
  const name = trimPunctuation(action.名称);
  const desc = formatThirdPerson(trimPunctuation(action.描述));
  
  // 尽量让名称和描述自然融合，使用玩家名字
  if (desc.includes(name)) {
    actionText += `${userName}决定${desc}`;
  } else {
    actionText += `${userName}决定着手“${name}”，${desc}`;
  }

  // 3. 融合回报预期
  if (action.回报预期) {
    const reward = formatThirdPerson(trimPunctuation(action.回报预期));
    const connectors = ['，以期能', '，若是顺利或许能', '，只盼借此', '，图个'];
    actionText += `${pick(connectors)}${reward}`;
  }

  // 4. 融合风险评估（用修仙口吻）- 根据要求已移除负面风险描述
  // const hasRisk = action.风险评估 && !['无', '无风险', ''].includes(action.风险评估.trim());
  // if (hasRisk) {
  //   const risk = formatThirdPerson(trimPunctuation(action.风险评估!));
  //   const riskConnectors = ['。虽说此举', '。然则', '。只是需得小心'];
  //   actionText += `${pick(riskConnectors)}${risk}，但${userName}心意已决，自当谨慎行事`;
  // }

  // 5. 融合时限（如果有）
  if (action.时限) {
    const timeLimit = trimPunctuation(action.时限);
    actionText += `。此事不可拖延，必须在${timeLimit}内有个结果`;
  }

  // 6. 结尾语气词
  actionText += pick(['。', '，且看天意如何。', '，静待其变。', '，以观后效。']);

  sendToInput(actionText);
  console.info('[行动提示] 选择行动:', action, '文本长度:', actionText.length);
};

// 选择顺势而为（推剧情）
const selectStoryAction = () => {
  let actionText = '';
  const userName = getUserName();
  
  // 1. 优先判断紧急状态（战斗/渡劫）
  if (store.本尊?.战斗状态?.正在战斗) {
    const enemies = store.本尊.当前敌人 || [];
    const enemyNames = enemies.map(e => e.名称).join('、') || '强敌';
    actionText = `眼下正与${enemyNames}激烈交锋，局势瞬息万变。${userName}无暇他顾，决定集中全部心神应对眼前斗法，见招拆招，寻找破局制胜之机。`;
  } else if (store.本尊?.渡劫状态?.正在渡劫) {
    actionText = `天威浩荡，劫云压顶。${userName}不敢有丝毫分心，决定全力运转功法，调动全身底蕴抵御重重天劫，以期顺利破境。`;
  } else {
    // 2. 结合当前处境或地点
    if (store.当前处境) {
      const situation = formatThirdPerson(store.当前处境);
      actionText += `眼下${trimPunctuation(situation)}，`;
    } else if (store.本尊?.行踪?.当前区域) {
      actionText += `身处${store.本尊.行踪.当前区域}，`;
    } else {
      actionText += `此时此刻，`;
    }

    // 3. 寻找主线任务或正在进行的任务
    const quests = Object.values(store.任务列表 || {});
    const mainQuest = quests.find(q => q.类型 === '主线' && q.状态 === '进行中');
    const anyQuest = quests.find(q => q.状态 === '进行中');
    const targetQuest = mainQuest || anyQuest;

    if (targetQuest) {
      const questName = trimPunctuation(targetQuest.名称);
      const questTarget = trimPunctuation(targetQuest.目标);
      const questPhrases = [
        `${userName}心中记挂着“${questName}”一事，决定顺应局势，继续朝着“${questTarget}”的方向稳步推进，不生枝节。`,
        `为早日达成“${questName}”之图谋，${userName}决定按部就班，将心思放在“${questTarget}”上，且看事情如何顺理成章地演变。`
      ];
      actionText += pick(questPhrases);
    } else {
      // 4. 默认的顺势而为
      const storyPhrases = [
        `${userName}审时度势，决定顺应眼前局势自然发展。不刻意节外生枝，亦不强求意外之喜，只是稳扎稳打应对当下，且看事情如何演变。`,
        `面对当前状况，${userName}心中已有计较，决定按部就班推进手头之事。修仙之路虽多变数，但此刻只需顺势而为，见招拆招，让一切水到渠成。`,
        `${userName}静观其变，决定不作过激之举，而是顺着事情原本脉络继续前行。兵来将挡，水来土掩，且看局势下一步如何自然展开。`
      ];
      actionText += pick(storyPhrases);
    }
  }
  
  sendToInput(actionText);
  console.info('[行动提示] 选择顺势而为，文本长度:', actionText.length);
};

// 选择随缘而行
const selectRandomAction = () => {
  let actionText = '';
  const userName = getUserName();
  
  if (store.当前处境) {
    const situation = formatThirdPerson(store.当前处境);
    actionText += `眼下${trimPunctuation(situation)}，`;
  } else {
    actionText += `此时此刻，`;
  }
  
  const randomPhrases = [
    `${userName}一时也无甚明确打算，索性便随缘而行。不刻意强求机缘，只在这四周随遇而安地游历，权当磨砺心境，且看冥冥之中，天道作何安排，又是否有意想不到的变数或造化主动找上门来。`,
    `倒不如暂且放下繁杂念头，顺其自然探索一番。修仙本是逆天而行与顺应天道并存，此刻${userName}便不设目标，信步由缰，静观其变，看看这周遭天地间，是否藏着未被发觉的暗流或机缘。`,
    `${userName}决定不拘泥于既定计划，就这般随心所欲四处游走。世间万物皆有定数，有时刻意寻觅反落了下乘，不如放空心神，随缘而动，或许能在不经意间撞破隐秘，亦或结下善缘。`
  ];
  
  actionText += pick(randomPhrases);
  
  sendToInput(actionText);
  console.info('[行动提示] 选择随缘而行，文本长度:', actionText.length);
};
</script>

<style lang="scss" scoped>
.action-menu-panel {
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 4px;
}

// 区块通用样式
.situation-section,
.actions-section {
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 14px;
}

.section-title {
  font-size: 14px;
  font-weight: bold;
  color: var(--text-accent);
  margin-bottom: 12px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;

  .title-left {
    display: flex;
    align-items: center;
    gap: 8px;
    
    i {
      color: var(--accent-color);
    }
  }

  .title-right {
    display: flex;
    align-items: center;
    gap: 8px;
  }

  .toggle-btn {
    background: var(--bg-primary);
    border: 1px solid var(--border-color);
    color: var(--text-secondary);
    cursor: pointer;
    padding: 4px 8px;
    border-radius: 12px;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;

    i {
      font-size: 14px;
    }

    &:hover {
      border-color: var(--border-active);
      color: var(--text-primary);
    }

    &.active {
      color: #4ade80;
      border-color: rgba(74, 222, 128, 0.3);
      background: rgba(74, 222, 128, 0.05);
    }
  }

  .refresh-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 4px;
    border-radius: 50%;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;

    &:hover {
      background: var(--button-bg);
      color: var(--accent-color);
    }
    
    i {
      font-size: 12px;
      color: inherit;
    }
  }

  .action-count {
    font-size: 12px;
    font-weight: normal;
    color: var(--text-secondary);
    background: var(--button-bg);
    padding: 2px 8px;
    border-radius: 10px;
  }
}

// 当前处境
.situation-content {
  font-size: 13px;
  color: var(--text-primary);
  line-height: 1.6;
  padding: 10px 12px;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: 8px;
}

// 无行动提示
.no-actions {
  text-align: center;
  padding: 30px 20px;
  color: var(--text-secondary);

  i {
    font-size: 36px;
    margin-bottom: 12px;
    color: var(--accent-color);
    opacity: 0.5;
  }

  p {
    margin: 4px 0;
    font-size: 14px;
  }

  .hint {
    font-size: 12px;
    color: var(--text-secondary);
    opacity: 0.8;
  }

  &.disabled-state {
    i {
      color: var(--text-secondary);
      opacity: 0.3;
    }
  }
}

// 行动卡片列表
.action-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-bottom: 10px;
}

// 行动卡片
.action-card {
  display: flex;
  gap: 12px;
  padding: 12px;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;

  &:hover {
    border-color: var(--border-active);
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
  }

  &:active {
    transform: translateY(0);
  }

  // 紧急任务样式
  &.urgent {
    border-color: #ff6b6b;
    background: linear-gradient(135deg, var(--bg-primary) 0%, rgba(255, 107, 107, 0.1) 100%);

    .time-limit {
      animation: pulse 2s infinite;
    }
  }

  // NSFW 子类卡片边框发光
  &.nsfw-双修 {
    border-color: rgba(219, 39, 119, 0.4);
    &:hover {
      border-color: #db2777;
      box-shadow: 0 4px 16px rgba(219, 39, 119, 0.25);
    }
  }
  &.nsfw-亲密 {
    border-color: rgba(192, 38, 211, 0.3);
    &:hover {
      border-color: #c026d3;
      box-shadow: 0 4px 16px rgba(192, 38, 211, 0.2);
    }
  }
  &.nsfw-调情 {
    border-color: rgba(225, 29, 72, 0.3);
    &:hover {
      border-color: #e11d48;
      box-shadow: 0 4px 16px rgba(225, 29, 72, 0.2);
    }
  }

  // 随缘而行特殊样式
  &.random-action {
    border-style: dashed;
    opacity: 0.85;

    &:hover {
      opacity: 1;
      border-style: solid;
    }
  }

  // 顺势而为特殊样式
  &.story-action {
    border-color: rgba(168, 85, 247, 0.4);
    background: linear-gradient(135deg, var(--bg-primary) 0%, rgba(168, 85, 247, 0.05) 100%);

    &:hover {
      border-color: #a855f7;
      box-shadow: 0 4px 12px rgba(168, 85, 247, 0.15);
    }
  }
}

// 常驻选项区域
.permanent-actions {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 16px;
  padding-top: 16px;
  border-top: 1px dashed var(--border-color);
}

// 行动图标
.action-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;

  i {
    font-size: 18px;
    color: #fff;
  }

  // 不同类型的颜色
  &.icon-探索 {
    background: linear-gradient(135deg, #4ade80, #22c55e);
  }
  &.icon-任务 {
    background: linear-gradient(135deg, #60a5fa, #3b82f6);
  }
  &.icon-交易 {
    background: linear-gradient(135deg, #fbbf24, #f59e0b);
  }
  &.icon-结交 {
    background: linear-gradient(135deg, #a78bfa, #8b5cf6);
  }
  &.icon-争夺 {
    background: linear-gradient(135deg, #f87171, #ef4444);
  }
  &.icon-修炼 {
    background: linear-gradient(135deg, #38bdf8, #0ea5e9);
  }
  &.icon-红颜 {
    background: linear-gradient(135deg, #fb7185, #f43f5e);
  }
  // NSFW 子类图标样式
  &.icon-nsfw-双修 {
    background: linear-gradient(135deg, #f472b6, #db2777);
    box-shadow: 0 0 8px rgba(219, 39, 119, 0.4);
  }
  &.icon-nsfw-亲密 {
    background: linear-gradient(135deg, #e879f9, #c026d3);
    box-shadow: 0 0 8px rgba(192, 38, 211, 0.4);
  }
  &.icon-nsfw-调情 {
    background: linear-gradient(135deg, #ff6b9d, #e11d48);
    box-shadow: 0 0 8px rgba(225, 29, 72, 0.3);
  }
  &.icon-随机 {
    background: linear-gradient(135deg, #94a3b8, #64748b);
  }
  &.icon-剧情 {
    background: linear-gradient(135deg, #c084fc, #9333ea);
  }
}

// 行动信息
.action-info {
  flex: 1;
  min-width: 0;
}

.action-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 4px;
}

.action-name {
  font-size: 14px;
  font-weight: bold;
  color: var(--text-primary);
}

.action-type-tag {
  font-size: 10px;
  padding: 2px 6px;
  background: var(--button-bg);
  color: var(--text-secondary);
  border-radius: 4px;

  // NSFW 子类标签样式
  &.tag-nsfw-双修 {
    background: linear-gradient(135deg, rgba(244, 114, 182, 0.2), rgba(219, 39, 119, 0.2));
    color: #f472b6;
    border: 1px solid rgba(219, 39, 119, 0.3);
  }
  &.tag-nsfw-亲密 {
    background: linear-gradient(135deg, rgba(232, 121, 249, 0.2), rgba(192, 38, 211, 0.2));
    color: #e879f9;
    border: 1px solid rgba(192, 38, 211, 0.3);
  }
  &.tag-nsfw-调情 {
    background: linear-gradient(135deg, rgba(255, 107, 157, 0.2), rgba(225, 29, 72, 0.2));
    color: #ff6b9d;
    border: 1px solid rgba(225, 29, 72, 0.3);
  }
}

.action-source {
  font-size: 11px;
  color: var(--text-secondary);
  margin-bottom: 4px;

  i {
    margin-right: 4px;
    color: var(--accent-color);
  }
}

.action-desc {
  font-size: 12px;
  color: var(--text-primary);
  line-height: 1.5;
  margin-bottom: 8px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

// 回报与风险
.action-meta {
  display: flex;
  gap: 12px;
  font-size: 11px;

  .reward,
  .risk {
    display: flex;
    align-items: center;
    gap: 4px;
  }

  .reward {
    color: #4ade80;

    i {
      color: #fbbf24;
    }
  }

  .risk {
    color: #f87171;

    i {
      color: #ef4444;
    }
  }
}

// 时限警告
.time-limit {
  margin-top: 6px;
  font-size: 11px;
  color: #ff6b6b;
  display: flex;
  align-items: center;
  gap: 4px;

  i {
    color: #ff6b6b;
  }
}

// 优先级指示器
.priority-indicator {
  position: absolute;
  top: 8px;
  right: 8px;
  font-size: 10px;
  color: var(--accent-color);
  opacity: 0.6;

  &.priority-5 {
    color: #fbbf24;
    opacity: 1;
  }
  &.priority-4 {
    color: #fb923c;
  }
  &.priority-3 {
    color: var(--accent-color);
  }
}

// 脉冲动画
@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}

// 手机端适配
@media screen and (max-width: 480px) {
  .action-menu-panel {
    gap: 12px;
  }

  .situation-section,
  .actions-section {
    padding: 12px;
  }

  .section-title {
    font-size: 13px;
    margin-bottom: 10px;
  }

  .action-card {
    padding: 10px;
    gap: 10px;
  }

  .action-icon {
    width: 36px;
    height: 36px;

    i {
      font-size: 16px;
    }
  }

  .action-name {
    font-size: 13px;
  }

  .action-desc {
    font-size: 11px;
  }

  .action-meta {
    font-size: 10px;
    gap: 8px;
  }
}
</style>
