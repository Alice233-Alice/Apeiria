<template>
  <div class="panel gallery-panel">
    <div v-if="store.hasGalleryCards" class="gallery-container">
      <div
        v-for="(card, index) in store.galleryCards"
        :key="index"
        class="gallery-card"
        :class="{ flipped: card.isFlipped }"
        @click="store.toggleCardFlip(index)"
      >
        <div class="card-inner">
          <!-- 正面 -->
          <div class="card-face card-front">
            <img :src="card.front" :alt="card.frontName || card.name" />
            <div class="card-name-bar">{{ card.frontName || card.name }}</div>
          </div>
          <!-- 背面 -->
          <div class="card-face card-back">
            <div class="back-content">
              <img :src="card.back" :alt="card.backName || card.name" class="back-image" />
              <div class="back-info-panel">
                <div class="back-name">{{ card.backName || card.name }}</div>
                <div class="back-text">「{{ card.backText }}」</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div v-else class="empty-hint">当前场景暂无角色卡片</div>
  </div>
</template>

<script setup lang="ts">
import { useDataStore } from '../store';

const store = useDataStore();
</script>

<style lang="scss" scoped>
.gallery-panel {
  padding: 16px !important;
  display: flex;
  flex-direction: column;
  align-items: center;

  .gallery-container {
    display: inline-flex;
    flex-direction: row;
    gap: 20px;
    overflow-x: auto;
    overflow-y: hidden;
    padding-bottom: 10px;
    max-width: 100%;

    &::-webkit-scrollbar {
      height: 8px;
    }

    &::-webkit-scrollbar-track {
      background: var(--bg-secondary);
      border-radius: 4px;
    }

    &::-webkit-scrollbar-thumb {
      background: var(--button-bg);
      border-radius: 4px;

      &:hover {
        background: var(--button-hover);
      }
    }
  }

  .gallery-card {
    flex-shrink: 0;
    width: 280px;
    aspect-ratio: 2 / 3;
    perspective: 1000px;
    cursor: pointer;
  }

  .card-inner {
    position: relative;
    width: 100%;
    height: 100%;
    transition: transform 0.6s ease;
    transform-style: preserve-3d;
    border-radius: 12px;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.5);
  }

  .gallery-card.flipped .card-inner {
    transform: rotateY(180deg);
  }

  .card-face {
    position: absolute;
    width: 100%;
    height: 100%;
    backface-visibility: hidden;
    border-radius: 12px;
    overflow: hidden;
    border: 2px solid var(--border-color);
  }

  .card-front {
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .card-name-bar {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 12px;
      background: linear-gradient(to top, rgba(0, 0, 0, 0.85), transparent);
      color: #fff;
      font-size: 16px;
      font-weight: bold;
      text-align: center;
      text-shadow: 0 2px 6px rgba(0, 0, 0, 0.9);
    }
  }

  .card-back {
    transform: rotateY(180deg);
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);

    .back-content {
      width: 100%;
      height: 100%;
      position: relative;

      .back-image {
        width: 100%;
        height: 100%;
        object-fit: cover;
      }

      .back-info-panel {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        padding: 20px 16px;
        background: linear-gradient(to top, rgba(0, 0, 0, 0.9) 0%, rgba(0, 0, 0, 0.7) 50%, transparent 100%);
        text-align: center;

        .back-name {
          font-size: 18px;
          font-weight: bold;
          color: #a0c0ff;
          margin-bottom: 8px;
          text-shadow:
            0 0 15px rgba(100, 150, 255, 0.6),
            0 2px 4px rgba(0, 0, 0, 0.8);
        }

        .back-text {
          font-size: 14px;
          color: #d0e0f0;
          line-height: 1.6;
          font-style: italic;
          text-shadow: 0 1px 3px rgba(0, 0, 0, 0.8);
        }
      }
    }
  }

  .gallery-card::after {
    content: '点击翻转';
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 10px;
    background: rgba(0, 0, 0, 0.6);
    color: #a0b8d0;
    font-size: 11px;
    border-radius: 12px;
    opacity: 0;
    transition: opacity 0.3s;
    pointer-events: none;
    z-index: 10;
  }

  .gallery-card:hover::after {
    opacity: 1;
  }

  .gallery-card.flipped::after {
    content: '点击翻回';
  }

  .empty-hint {
    text-align: center;
    padding: 20px;
    color: #506070;
    font-style: italic;
  }
}

// 手机端适配
@media screen and (max-width: 480px) {
  .gallery-panel {
    padding: 12px !important;

    .gallery-container {
      gap: 14px;
    }

    .gallery-card {
      width: 200px;
    }

    .card-front {
      .card-name-bar {
        padding: 10px;
        font-size: 14px;
      }
    }

    .card-back {
      .back-content {
        .back-info-panel {
          padding: 16px 12px;

          .back-name {
            font-size: 15px;
          }

          .back-text {
            font-size: 12px;
          }
        }
      }
    }

    .gallery-card::after {
      font-size: 10px;
      padding: 3px 8px;
    }
  }
  
  .preview-close {
    top: -40px;
    width: 36px;
    height: 36px;
    font-size: 18px;
  }
  
  .preview-name {
    font-size: 16px;
    padding: 6px 16px;
  }
}

// 超小屏幕适配
@media screen and (max-width: 360px) {
  .gallery-panel {
    .gallery-card {
      width: 160px;
    }
  }
}
</style>