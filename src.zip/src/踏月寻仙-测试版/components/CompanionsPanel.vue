<template>
  <div class="panel companions-panel">
    <div class="companions-list">
      <div v-for="(companion, name) in store.红颜" :key="name" class="companion-card" :class="{ expanded: isExpanded(name) }">
        <button class="companion-header" type="button" @click="toggleExpanded(name)">
          <div class="header-main">
            <span class="companion-name">{{ name }}</span>
            <div class="companion-badges">
              <span class="relation-badge">{{ companion.关系 }}</span>
              <span v-if="companion.关系上下文?.当前情绪" class="context-badge">
                {{ companion.关系上下文.当前情绪 }}
              </span>
            </div>
          </div>

          <div class="header-side">
            <span class="companion-realm" :style="{ color: getRealmColor(companion.等级) }">
              {{ getRealmDescription(companion.等级, companion.境界描述) }}
            </span>
            <i class="fa-solid" :class="isExpanded(name) ? 'fa-chevron-up' : 'fa-chevron-down'"></i>
          </div>
        </button>

        <div class="companion-favor">
          <div class="favor-label">好感度</div>
          <div class="favor-bar">
            <div
              class="favor-fill"
              :style="{
                width: `${Math.min(Math.abs(companion.好感度) / 2, 100)}%`,
                backgroundColor: companion.好感度 >= 0 ? '#ff6b9d' : '#6b7fff',
              }"
            ></div>
          </div>
          <div class="favor-value">{{ companion.好感度 }}</div>
        </div>

        <div v-if="isExpanded(name)" class="context-section">
          <div class="context-title">
            <i class="fa-solid fa-feather-pointed"></i>
            <span>心迹微澜</span>
          </div>

          <div v-if="getContextEntries(companion).length > 0" class="context-list">
            <div v-for="entry in getContextEntries(companion)" :key="entry.label" class="context-item">
              <div class="context-label">{{ entry.label }}</div>
              <div class="context-value">{{ entry.value }}</div>
            </div>
          </div>

          <div v-else class="context-empty">
            眼下尚无可书之绪。待相与日深，此间自会渐记其心念、所求、所忌与未竟之约。
          </div>
        </div>
      </div>

      <div v-if="Object.keys(store.红颜).length === 0" class="empty-hint">孑然一身，尚无红颜知己</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { REALM_NAMES, REALM_STAGES, getRealmColor } from '../schema';
import { useDataStore } from '../store';

const store = useDataStore();
const expandedName = ref('');

const CONTEXT_LABELS = {
  态度缘由: '此念所起',
  关系诉求: '心中所求',
  相处禁忌: '所忌',
  未了约定: '未竟之约',
} as const;

watch(
  () => Object.keys(store.红颜),
  names => {
    if (names.length === 0) {
      expandedName.value = '';
      return;
    }

    if (!expandedName.value || !names.includes(expandedName.value)) {
      expandedName.value = names[0] ?? '';
    }
  },
  { immediate: true },
);

function getRealmDescription(levelRaw: unknown, fallbackRaw: unknown): string {
  const fallback = String(fallbackRaw ?? '').trim();
  const level = Number(levelRaw);
  const maxLevel = REALM_NAMES.length * REALM_STAGES.length;

  if (!Number.isFinite(level) || level < 1) {
    return fallback || '练气初期';
  }

  const normalizedLevel = Math.min(Math.floor(level), maxLevel);
  const majorIdx = Math.floor((normalizedLevel - 1) / REALM_STAGES.length);
  const minorIdx = (normalizedLevel - 1) % REALM_STAGES.length;

  const major = REALM_NAMES[majorIdx];
  const minor = REALM_STAGES[minorIdx];

  if (!major || !minor) {
    return fallback || '练气初期';
  }

  return `${major}${minor}`;
}

function isExpanded(name: string): boolean {
  return expandedName.value === name;
}

function toggleExpanded(name: string): void {
  expandedName.value = expandedName.value === name ? '' : name;
}

function getContextEntries(companion: Record<string, any>) {
  const context = companion.关系上下文 ?? {};
  return Object.entries(CONTEXT_LABELS)
    .map(([key, label]) => ({
      label,
      value: String(context[key] ?? '').trim(),
    }))
    .filter(entry => entry.value);
}
</script>

<style lang="scss" scoped>
.companions-panel {
  padding: 16px;

  .companions-list {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }

  .companion-card {
    padding: 14px;
    background: var(--bg-secondary);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    transition: all 0.2s ease;

    &.expanded {
      border-color: rgba(255, 176, 192, 0.35);
      background: linear-gradient(180deg, rgba(255, 176, 192, 0.04) 0%, var(--bg-secondary) 100%);
    }

    .companion-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      width: 100%;
      padding: 0;
      margin-bottom: 12px;
      background: transparent;
      border: none;
      cursor: pointer;
      text-align: left;
    }

    .header-main {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-width: 0;
    }

    .companion-name {
      font-size: 15px;
      font-weight: bold;
      color: #ffb0c0;
    }

    .companion-badges {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .relation-badge,
    .context-badge {
      padding: 4px 12px;
      border-radius: 999px;
      font-size: 12px;
      line-height: 1;
      border: 1px solid rgba(255, 176, 192, 0.24);
    }

    .relation-badge {
      color: #f6d4dc;
      background: rgba(135, 99, 142, 0.18);
    }

    .context-badge {
      color: #ffd38a;
      background: rgba(255, 211, 138, 0.08);
      border-color: rgba(255, 211, 138, 0.22);
    }

    .header-side {
      display: flex;
      align-items: center;
      gap: 12px;
      margin-left: 12px;
    }

    .companion-realm {
      font-size: 12px;
    }

    .header-side i {
      color: var(--text-secondary);
      font-size: 13px;
    }

    .companion-favor {
      display: flex;
      align-items: center;
      gap: 8px;

      .favor-label {
        font-size: 11px;
        color: var(--text-secondary);
        min-width: 42px;
      }

      .favor-bar {
        flex: 1;
        height: 6px;
        background: var(--progress-bg);
        border-radius: 3px;
        overflow: hidden;

        .favor-fill {
          height: 100%;
          border-radius: 3px;
          transition: width 0.3s ease;
        }
      }

      .favor-value {
        font-size: 12px;
        color: var(--text-accent);
        min-width: 30px;
        text-align: right;
      }
    }

    .context-section {
      margin-top: 14px;
      padding-top: 14px;
      border-top: 1px dashed rgba(255, 176, 192, 0.18);
    }

    .context-title {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
      font-size: 14px;
      color: #f3b4c8;

      i {
        color: #f58ca8;
      }
    }

    .context-list {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .context-item {
      padding: 12px 14px;
      background: rgba(255, 255, 255, 0.02);
      border: 1px solid rgba(255, 176, 192, 0.1);
      border-radius: 10px;
    }

    .context-label {
      margin-bottom: 6px;
      font-size: 12px;
      color: var(--text-secondary);
    }

    .context-value {
      font-size: 14px;
      line-height: 1.6;
      color: var(--text-accent);
    }

    .context-empty {
      padding: 14px;
      border-radius: 10px;
      font-size: 13px;
      line-height: 1.7;
      color: var(--text-secondary);
      background: rgba(255, 255, 255, 0.02);
      border: 1px dashed rgba(255, 176, 192, 0.12);
    }
  }

  .empty-hint {
    text-align: center;
    padding: 20px;
    color: #506070;
    font-style: italic;
  }
}

@media screen and (max-width: 480px) {
  .companions-panel {
    padding: 12px;

    .companion-card {
      padding: 12px;

      .companion-name {
        font-size: 14px;
      }

      .header-side {
        gap: 8px;
      }

      .companion-realm {
        font-size: 11px;
      }

      .favor-label {
        font-size: 10px;
      }

      .favor-bar {
        height: 5px;
      }

      .favor-value {
        font-size: 11px;
      }

      .context-title {
        font-size: 13px;
      }

      .context-item {
        padding: 10px 12px;
      }

      .context-value {
        font-size: 13px;
      }
    }
  }
}
</style>
