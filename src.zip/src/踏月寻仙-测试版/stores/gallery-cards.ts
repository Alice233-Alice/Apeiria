import { getCharacterImages, resetDualSoulSession } from '../character-assets';

export interface VisualCard {
    name: string;
    img_code: string;
    back_img_code?: string;
    back_text: string;
}

export interface GalleryCard {
    name: string;
    front: string;
    back: string;
    backText: string;
    isFlipped: boolean;
    frontName?: string;
    backName?: string;
}

function parseVisualCards(content: string): VisualCard[] {
    try {
        const match = content.match(/<visual_cards>\s*([\s\S]*?)\s*<\/visual_cards>/);
        if (!match) return [];

        const jsonStr = match[1].trim();
        if (!jsonStr) return [];

        const cards = JSON.parse(jsonStr) as VisualCard[];
        if (!Array.isArray(cards)) {
            console.warn('[图鉴] visual_cards 不是数组');
            return [];
        }

        return cards.filter(card =>
            card.name &&
            card.img_code &&
            typeof card.back_text === 'string',
        );
    } catch (e) {
        console.error('[图鉴] 解析 visual_cards 失败', e);
        return [];
    }
}

function convertToGalleryCards(visualCards: VisualCard[]): GalleryCard[] {
    resetDualSoulSession();
    const result: GalleryCard[] = [];

    for (const card of visualCards) {
        const images = getCharacterImages(card.name, card.img_code, card.back_img_code);
        if (images === null) {
            console.info(`[图鉴] 跳过重复的 ${card.name} 卡片`);
            continue;
        }

        result.push({
            name: card.name,
            front: images.front,
            back: images.back,
            backText: card.back_text || '',
            isFlipped: false,
            frontName: images.frontName,
            backName: images.backName,
        });
    }

    return result;
}

export function extractGalleryCardsFromContent(content: string): GalleryCard[] {
    const visualCards = parseVisualCards(content);
    if (visualCards.length === 0) return [];
    return convertToGalleryCards(visualCards);
}

export function preloadGalleryCardImages(cards: GalleryCard[]): void {
    cards.forEach(card => {
        const frontImg = new Image();
        frontImg.src = card.front;

        const backImg = new Image();
        backImg.src = card.back;
    });
    console.info('[图鉴] 开始预加载', cards.length * 2, '张图片');
}
