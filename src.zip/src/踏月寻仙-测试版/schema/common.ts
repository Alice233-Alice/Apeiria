// ============================================================================
// 踏月寻仙 - 共享 Schema（物品、神通、品阶映射）
// ============================================================================

import { z } from 'zod';
import { REALM_LIFESPANS, REALM_NAMES, REALM_STAGES, REALM_THRESHOLDS } from './constants';
import { calculateBaseCombatPower } from './utils';

// 品阶容错映射
export const 品阶映射: Record<string, string> = {
    '凡': '凡', '凡阶': '凡', '凡级': '凡', '凡品': '凡',
    '黄': '黄', '黄阶': '黄', '黄级': '黄', '黄品': '黄',
    '玄': '玄', '玄阶': '玄', '玄级': '玄', '玄品': '玄',
    '地': '地', '地阶': '地', '地级': '地', '地品': '地',
    '天': '天', '天阶': '天', '天级': '天', '天品': '天',
    '仙': '仙', '仙阶': '仙', '仙级': '仙', '仙品': '仙',
    '圣': '圣', '圣阶': '圣', '圣级': '圣', '圣品': '圣',
    '先天': '先天', '先天阶': '先天', '先天级': '先天',
};

// 熟练度容错映射
export const 熟练度映射: Record<string, string> = {
    '入门': '入门', '初级': '入门', '初学': '入门', '新手': '入门',
    '熟练': '熟练', '中级': '熟练', '娴熟': '熟练', '小成': '熟练',
    '精通': '精通', '高级': '精通', '精湛': '精通',
    '大成': '大成', '大师': '大成', '宗师': '大成',
    '圆满': '圆满', '完美': '圆满', '极致': '圆满',
    '化境': '化境', '化神': '化境', '返璞归真': '化境', '出神入化': '化境',
};

function normalizeSkillProficiency(raw: unknown): string {
    const value = String(raw ?? '').trim().replace(/^["'“”‘’]+|["'“”‘’]+$/g, '');
    if (熟练度映射[value]) return 熟练度映射[value];
    if (value.includes('小成')) return '熟练';
    if (value.includes('中成')) return '精通';
    if (value.includes('大圆满')) return '圆满';
    return '入门';
}

// 物品 Schema
export const ItemSchema = z.object({
    名称: z.string().prefault(''),
    描述: z.string().prefault(''),
    品阶: z.string().prefault(''),
    数量: z.coerce.number().transform(v => Math.max(0, v)).prefault(1),
});

// 神通 Schema（本尊和红颜共用）
export const SkillSchema = z.object({
    名称: z.string().prefault(''),
    描述: z.string().prefault(''),
    类型: z.enum(['功法', '神通', '秘术']).prefault('神通'),
    品阶: z.string()
        .transform(v => 品阶映射[v] || '凡')
        .catch('凡'),
    熟练度: z.string()
        .transform(v => normalizeSkillProficiency(v))
        .catch('入门'),
    领悟时间: z.coerce.number().catch(() => Date.now()),
    威力等级: z.coerce.number().optional(),
}).transform(skill => {
    // 仅当威力等级不存在或为0时才计算
    if (!skill.威力等级 || skill.威力等级 === 0) {
        const 品阶权重: Record<string, number> = { 凡: 1, 黄: 2, 玄: 3, 地: 4, 天: 5, 仙: 6, 圣: 7, 先天: 8 };
        const 熟练度权重: Record<string, number> = { 入门: 1, 熟练: 2, 精通: 3, 大成: 4, 圆满: 5, 化境: 6 };

        const 品阶值 = 品阶权重[skill.品阶] || 1;
        const 熟练值 = 熟练度权重[skill.熟练度] || 1;

        return {
            ...skill,
            威力等级: 品阶值 * 10 + 熟练值,
        };
    }
    return skill;
});

// 背包类物品 Schema（自动过滤数量<=0的物品）
export const InventorySchema = z
    .record(z.string().describe('物品名'), ItemSchema)
    .prefault({})
    .transform(data => _.pickBy(data, ({ 数量 }) => 数量 > 0));

// 境界计算 transform（本尊和红颜共用）
export function computeRealmInfo(data: {
    等级: number;
    修为: number;
    已活岁月: number;
    尝试突破: boolean;
    神通列表?: Record<string, { 威力等级?: number }>;
    体质?: string;
}, includesCombatPower: boolean = false) {
    const level = data.等级;
    const 突破阈值 = REALM_THRESHOLDS[level - 1] ?? 100;
    const 寿元上限 = REALM_LIFESPANS[level - 1] ?? 100;
    const majorIdx = Math.floor((level - 1) / 4);
    const minorIdx = (level - 1) % 4;
    const 境界描述 = `${REALM_NAMES[majorIdx] ?? '练气'}${REALM_STAGES[minorIdx] ?? '初期'}`;
    const 寿元状态 = `${data.已活岁月}/${寿元上限}`;
    const 状态 = data.尝试突破 ? '突破中' : data.修为 >= 突破阈值 ? '瓶颈期' : '修炼中';
    const 进度 = `${((data.修为 / 突破阈值) * 100).toFixed(1)}%`;

    const base = { 突破阈值, 寿元上限, 境界描述, 寿元状态, 状态, 进度 };

    if (!includesCombatPower) return base;

    // 战力计算：境界基础（指数级） + 神通加成 + 体质加成
    const 境界战力 = calculateBaseCombatPower(level);
    const 神通列表 = Object.values(data.神通列表 || {});
    const 最高神通威力 = 神通列表.length > 0
        ? Math.max(...神通列表.map(s => s.威力等级 || 0))
        : 0;
    const 体质加成 = (() => {
        const 体质 = data.体质 || '';
        if (体质.includes('神')) return 500;
        if (体质.includes('圣')) return 200;
        if (体质.includes('道')) return 100;
        if (体质.includes('灵')) return 50;
        return 0;
    })();
    const 战力值 = 境界战力 + 最高神通威力 + 体质加成;

    return { ...base, 战力值 };
}
