﻿// ============================================================================// 角色图片资源配置 (Character Assets Configuration)
// 在这里配置所有角色的图片资源（正面和背面）
// ============================================================================

/**
 * 单个表情的图片配置
 */
export interface ExpressionImages {
    /** 正面图片 URL */
    front: string;
    /** 背面图片 URL（可选，如果不填则使用正面图片） */
    back?: string;
}

/**
 * 角色图片资源配置
 * 格式: { 角色名: { 表情代号: { front: 正面URL, back: 背面URL } } }
 *
 * 使用方法:
 * 1. 为每个角色创建一个对象
 * 2. 为每个表情/状态配置对应的正面和背面图片URL
 * 3. AI 输出时会根据 img_code 自动匹配对应的图片
 * 4. 如果不需要不同的背面图片，可以只填写 front，或使用简写形式
 */
export const CHARACTER_ASSETS: Record<string, Record<string, ExpressionImages | string>> = {
    // ============================================================================
    // 示例角色：孟十七
    // ============================================================================
    孟十七: {
        // 完整配置示例（有不同的正面和背面）
        normal: {
            front: 'https://files.catbox.moe/c1su29.jpg', // 日常/平静 - 正面
            back: 'https://files.catbox.moe/c1su29.jpg', // 日常/平静 - 背面（可以是不同的图片）
        },
        // 简写形式（正面和背面使用相同图片）
        shy: 'https://files.catbox.moe/8doe0f.jpg', // 害羞/脸红
        smile: 'https://files.catbox.moe/8doe0f.jpg', // 微笑/开心
        angry: 'https://files.catbox.moe/c1su29.jpg', // 生气/鼓嘴
        cry: 'https://files.catbox.moe/c1su29.jpg', // 哭泣/委屈
        surprise: 'https://files.catbox.moe/8doe0f.jpg', // 惊讶/瞪眼
    },

    // ============================================================================
    // 白清弦 - 剑道宗师
    // ============================================================================
    白清弦: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 虞汐颜 - 一体双魂（虞汐白头发/虞颜黑头发）
    // ============================================================================
    虞汐颜: {
        // 随机选择正面和背面图片
        // 特殊逻辑：正面虞汐时背面虞颜，正面虞颜时背面虞汐
        normal: {
            front: 'random_dual_front', // 特殊标记，随机选择虞汐或虞颜的正面
            back: 'random_dual_back',   // 特殊标记，自动选择另一个魂体的背面
        },
    },

    // ============================================================================
    // 许听雨
    // ============================================================================
    许听雨: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 南宫云裳
    // ============================================================================
    南宫云裳: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 晚棠 - 黄泉摆渡人
    // ============================================================================
    晚棠: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 梦杳泠
    // ============================================================================
    梦杳泠: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 阮忘忧
    // ============================================================================
    阮忘忧: {
        // 随机选择正面和背面图片
        normal: {
            front: 'random_front', // 特殊标记，表示从正面图片池中随机选择
            back: 'random_back',   // 特殊标记，表示从背面图片池中随机选择
        },
    },

    // ============================================================================
    // 添加更多角色示例
    // ============================================================================
    // 角色名2: {
    //   // 完整配置（不同的正面和背面）
    //   normal: {
    //     front: '正面图片URL',
    //     back: '背面图片URL',
    //   },
    //   // 简写配置（正面和背面相同）
    //   happy: '图片URL',
    //   sad: '图片URL',
    //   // ... 更多表情
    // },
};

/**
 * 角色名称别名映射
 * AI 按照世界书规则会分别输出 "虞汐" 和 "虞颜"，需要映射到 "虞汐颜" 的资源配置
 */
const CHARACTER_NAME_ALIASES: Record<string, string> = {
    '虞汐': '虞汐颜',
    '虞颜': '虞汐颜',
};

/**
 * 解析角色名称（支持别名映射）
 * @param name AI 输出的角色名
 * @returns 标准化后的资源配置名
 */
function resolveCharacterName(name: string): string {
    return CHARACTER_NAME_ALIASES[name] ?? name;
}

/**
 * 从原始角色名推断虞汐颜的优先魂体
 * @param originalName AI 输出的原始角色名
 * @returns 优先显示在正面的魂体，或 undefined 表示随机
 */
function inferPreferredSoul(originalName: string): '虞汐' | '虞颜' | undefined {
    if (originalName === '虞汐') return '虞汐';
    if (originalName === '虞颜') return '虞颜';
    return undefined;
}

/**
 * 角色图片池 - 用于随机选择
 * 格式: { 角色名: { front: [正面图片URL列表], back: [背面图片URL列表] } }
 */
export const CHARACTER_IMAGE_POOLS: Record<string, { front: string[]; back: string[] }> = {
    白清弦: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦1.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦2.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦3.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦4.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦5.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦18.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦19.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦20.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦21.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦22.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦38.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦36.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦31.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (40).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (40).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (30).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦6.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦7.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦8.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦9.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦10.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦11.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦15.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦16.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦17.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦25.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦24.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦23.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦15.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦26.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦27.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦28.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦29.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦30.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦37.png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (9).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (22).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (21).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (47).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (50).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (49).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/白清弦 (48).png',
        ],
    },
    许听雨: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (31).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (9).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (21).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/许听雨 (36).png',
        ],
    },
    虞汐颜: {
        // 虞汐的图片（白头发）
        虞汐_front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (44).png',
        ],
        虞汐_back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞汐 (40).png',
        ],
        // 虞颜的图片（黑头发）
        虞颜_front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (9).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (21).png',
        ],
        虞颜_back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (22).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (47).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (50).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (49).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/虞颜 (48).png',
        ],
    } as any,
    南宫云裳: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (9).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (49).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (59).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (54).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (53).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (50).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (48).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (36).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (61).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (60).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (57).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (56).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (55).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (58).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (47).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (40).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (62).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (65).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (64).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/南宫云裳 (63).png',
        ],
    },
    晚棠: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (9).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (21).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (22).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/晚棠 (23).png',
        ],
    },
    梦杳泠: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (9).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (19).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (21).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (22).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (54).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (53).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (49).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (34).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (48).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (47).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (50).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (40).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/梦杳泠 (28).png',
        ],
    },
    阮忘忧: {
        front: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (1).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (2).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (3).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (4).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (25).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (29).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (31).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (43).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (44).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (42).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (45).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (49).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (50).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (51).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (52).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (53).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (54).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (55).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (56).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (60).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (62).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (64).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (65).png',
        ],
        back: [
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (5).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (6).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (7).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (8).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (80).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (79).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (78).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (77).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (73).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (74).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (75).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (76).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (71).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (72).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (70).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (69).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (68).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (67).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (66).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (63).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (61).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (59).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (58).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (57).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (47).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (46).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (48).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (41).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (40).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (39).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (38).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (37).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (36).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (35).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (34).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (33).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (30).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (32).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (28).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (27).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (26).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (21).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (22).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (23).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (24).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (20).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (17).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (18).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (16).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (14).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (15).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (13).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (12).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (11).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (10).png',
            'https://pub-4d14ab94aa29488b977bc5be9f2a06ef.r2.dev/picgo/阮忘忧 (9).png',
        ],
    },
};

/**
 * 默认表情 - 当 AI 输出的 img_code 不存在时使用
 */
export const DEFAULT_EXPRESSION = 'normal';

/**
 * 默认卡片背景 - 当角色没有配置图片时使用的占位图
 */
export const DEFAULT_PLACEHOLDER = 'https://files.catbox.moe/placeholder.jpg';

/**
 * 从图片池中随机选择一张图片
 * 虞汐颜专用：缓存当前选择的魂体，以便正面和背面使用不同的魂体
 */
let cachedDualSoul: '虞汐' | '虞颜' | null = null;

/**
 * 会话缓存：记录已经为虞汐颜生成过的卡片
 * 避免在同一个消息楼层中生成多张虞汐颜卡片
 */
let dualSoulSessionUsed = false;

function getRandomImage(characterName: string, type: 'front' | 'back'): string {
    const pool = CHARACTER_IMAGE_POOLS[characterName];
    if (!pool) {
        console.warn(`[图鉴] 未找到角色 "${characterName}" 的图片池`);
        return DEFAULT_PLACEHOLDER;
    }

    const images = pool[type];
    if (!images || images.length === 0) {
        console.warn(`[图鉴] 角色 "${characterName}" 的 ${type} 图片池为空`);
        return DEFAULT_PLACEHOLDER;
    }

    // 随机选择一张图片
    const randomIndex = Math.floor(Math.random() * images.length);
    return images[randomIndex];
}

/**
 * 虞汐颜专用：获取一体双魂的图片和名字
 * 正面虞汐时背面虞颜，正面虞颜时背面虞汐
 *
 * 重要：每次调用此函数时，只会生成一对卡片（正面+背面）
 * 如果已经生成过，则返回 null，避免重复生成
 */
function getDualSoulImage(type: 'front' | 'back', preferredSoul?: '虞汐' | '虞颜'): { url: string; soulName: string } | null {
    const pool = CHARACTER_IMAGE_POOLS['虞汐颜'] as any;
    if (!pool) {
        console.warn(`[图鉴] 未找到虞汐颜的图片池`);
        return { url: DEFAULT_PLACEHOLDER, soulName: '虞汐颜' };
    }

    if (type === 'front') {
        // 如果已经生成过虞汐颜卡片，返回 null
        if (dualSoulSessionUsed) {
            console.info(`[图鉴] 虞汐颜卡片已生成，跳过重复生成`);
            return null;
        }

        // 标记为已使用
        dualSoulSessionUsed = true;

        // 正面：优先使用指定的魂体，否则随机选择
        const soul = preferredSoul ?? (Math.random() < 0.5 ? '虞汐' : '虞颜');
        cachedDualSoul = soul;
        const images = pool[`${soul}_front`];
        if (!images || images.length === 0) {
            console.warn(`[图鉴] 虞汐颜的 ${soul} 正面图片池为空`);
            return { url: DEFAULT_PLACEHOLDER, soulName: soul };
        }
        const randomIndex = Math.floor(Math.random() * images.length);
        console.info(`[图鉴] 虞汐颜正面选择: ${soul}`);
        return { url: images[randomIndex], soulName: soul };
    } else {
        // 背面：使用另一个魂体
        // 如果 cachedDualSoul 为 null，说明出现了异常调用顺序
        if (!cachedDualSoul) {
            console.error(`[图鉴] 错误：虞汐颜背面图片获取时，正面魂体未缓存`);
            return { url: DEFAULT_PLACEHOLDER, soulName: '虞汐颜' };
        }
        
        const soul = cachedDualSoul === '虞汐' ? '虞颜' : '虞汐';
        const images = pool[`${soul}_back`];
        if (!images || images.length === 0) {
            console.warn(`[图鉴] 虞汐颜的 ${soul} 背面图片池为空`);
            return { url: DEFAULT_PLACEHOLDER, soulName: soul };
        }
        const randomIndex = Math.floor(Math.random() * images.length);
        console.info(`[图鉴] 虞汐颜背面选择: ${soul}`);
        return { url: images[randomIndex], soulName: soul };
    }
}

/**
 * 标准化表情配置（将简写形式转换为完整形式）
 * 对于虞汐颜，还会返回对应的魂体名字
 *
 * 如果虞汐颜已经生成过卡片，则返回 null
 */
function normalizeExpressionImages(config: ExpressionImages | string, characterName: string, originalName?: string): (ExpressionImages & { frontName?: string; backName?: string }) | null {
    if (typeof config === 'string') {
        return { front: config, back: config };
    }

    // 处理虞汐颜的特殊逻辑
    if (characterName === '虞汐颜') {
        if (config.front === 'random_dual_front') {
            const preferredSoul = inferPreferredSoul(originalName ?? characterName);
            const frontResult = getDualSoulImage('front', preferredSoul);

            // 如果返回 null，说明已经生成过了
            if (frontResult === null) {
                return null;
            }

            const backResult = getDualSoulImage('back');
            if (backResult === null) {
                return null;
            }

            return {
                front: frontResult.url,
                back: backResult.url,
                frontName: frontResult.soulName,
                backName: backResult.soulName
            };
        }
    }

    // 处理普通随机图片
    let front = config.front;
    let back = config.back ?? config.front;

    if (front === 'random_front') {
        front = getRandomImage(characterName, 'front');
    }
    if (back === 'random_back') {
        back = getRandomImage(characterName, 'back');
    }

    return { front, back };
}


/**
 * 获取角色正面图片URL
 * @param characterName 角色名
 * @param imgCode 表情代号
 * @returns 正面图片URL
 */
export function getCharacterImage(characterName: string, imgCode: string): string {
    const resolvedName = resolveCharacterName(characterName);
    const character = CHARACTER_ASSETS[resolvedName];
    if (!character) {
        console.warn(`[图鉴] 未找到角色 "${characterName}" 的图片配置，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }

    const config = character[imgCode] ?? character[DEFAULT_EXPRESSION];
    if (!config) {
        console.warn(`[图鉴] 角色 "${characterName}" 没有表情 "${imgCode}" 的图片，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }

    const normalized = normalizeExpressionImages(config, resolvedName, characterName);
    if (!normalized) {
        console.warn(`[图鉴] 角色 "${characterName}" 图片标准化失败，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }
    return normalized.front;
}

/**
 * 获取角色背面图片URL
 * @param characterName 角色名
 * @param imgCode 表情代号
 * @returns 背面图片URL
 */
export function getCharacterBackImage(characterName: string, imgCode: string): string {
    const resolvedName = resolveCharacterName(characterName);
    const character = CHARACTER_ASSETS[resolvedName];
    if (!character) {
        console.warn(`[图鉴] 未找到角色 "${characterName}" 的图片配置，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }

    const config = character[imgCode] ?? character[DEFAULT_EXPRESSION];
    if (!config) {
        console.warn(`[图鉴] 角色 "${characterName}" 没有表情 "${imgCode}" 的图片，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }

    const normalized = normalizeExpressionImages(config, resolvedName, characterName);
    if (!normalized || !normalized.back) {
        console.warn(`[图鉴] 角色 "${characterName}" 背面图片标准化失败，使用占位图`);
        return DEFAULT_PLACEHOLDER;
    }
    return normalized.back;
}

/**
 * 获取角色正面和背面图片URL
 * 对于虞汐颜，会返回对应的魂体名字
 *
 * 重要：每次页面加载时，虞汐颜只会生成一张卡片
 * @param characterName 角色名
 * @param imgCode 正面表情代号
 * @param backImgCode 背面表情代号（可选，默认与正面相同）
 * @returns { front: 正面URL, back: 背面URL, frontName?: 正面名字, backName?: 背面名字 } 或 null（如果虞汐颜已生成）
 */
export function getCharacterImages(
    characterName: string,
    imgCode: string,
    backImgCode?: string,
): { front: string; back: string; frontName?: string; backName?: string } | null {
    const resolvedName = resolveCharacterName(characterName);
    const character = CHARACTER_ASSETS[resolvedName];
    if (!character) {
        console.warn(`[图鉴] 未找到角色 "${characterName}" 的图片配置，使用占位图`);
        return { front: DEFAULT_PLACEHOLDER, back: DEFAULT_PLACEHOLDER };
    }

    const frontConfig = character[imgCode] ?? character[DEFAULT_EXPRESSION];
    if (!frontConfig) {
        console.warn(`[图鉴] 角色 "${characterName}" 没有表情 "${imgCode}" 的图片，使用占位图`);
        return { front: DEFAULT_PLACEHOLDER, back: DEFAULT_PLACEHOLDER };
    }

    const frontNormalized = normalizeExpressionImages(frontConfig, resolvedName, characterName);

    // 如果返回 null（虞汐颜已生成），则返回 null
    if (frontNormalized === null) {
        return null;
    }

    // 如果指定了 backImgCode，则单独获取背面图片
    let backUrl = frontNormalized.back;
    if (backImgCode && backImgCode !== imgCode) {
        const backConfig = character[backImgCode] ?? character[DEFAULT_EXPRESSION];
        if (backConfig) {
            const backNormalized = normalizeExpressionImages(backConfig, resolvedName, characterName);
            if (backNormalized && backNormalized.back) {
                backUrl = backNormalized.back;
            }
        } else {
            console.warn(`[图鉴] 角色 "${characterName}" 没有背面表情 "${backImgCode}"，使用正面背面`);
        }
    }

    if (!backUrl) {
        console.warn(`[图鉴] 角色 "${characterName}" 背面图片缺失，使用正面图片`);
        backUrl = frontNormalized.front;
    }

    return {
        front: frontNormalized.front,
        back: backUrl,
        frontName: frontNormalized.frontName,
        backName: frontNormalized.backName
    };
}

/**
 * 重置虞汐颜的会话缓存
 * 在新的消息楼层或页面重新加载时调用
 */
export function resetDualSoulSession() {
    dualSoulSessionUsed = false;
    cachedDualSoul = null;
    console.info('[图鉴] 虞汐颜会话缓存已重置');
}

/**
 * 获取角色所有可用的表情列表
 * @param characterName 角色名
 * @returns 表情代号列表
 */
export function getAvailableExpressions(characterName: string): string[] {
    const resolvedName = resolveCharacterName(characterName);
    const character = CHARACTER_ASSETS[resolvedName];
    return character ? Object.keys(character) : [];
}

/**
 * 检查角色是否已配置
 * @param characterName 角色名
 * @returns 是否已配置
 */
export function isCharacterConfigured(characterName: string): boolean {
    const resolvedName = resolveCharacterName(characterName);
    return resolvedName in CHARACTER_ASSETS;
}
