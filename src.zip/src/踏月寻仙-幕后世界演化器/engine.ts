import { Schema } from '../踏月寻仙-测试版/schema';
import { maybeEnhanceHook } from './api-client';
import { readSettings } from './settings';

const SCRIPT_NAME = '幕后世界演化器';
const GENERATED_SOURCE = '幕后世界演化器';
const CHAT_STATE_KEY = '__踏月寻仙_幕后世界演化器';
const RUNTIME_SNAPSHOT_EVENT = '踏月寻仙:幕后世界演化器:runtime-snapshot';

const ActorStateSchema = z.object({
  幕后状态: z.enum(['静待', '闭关', '查案', '养伤', '觅药', '待护法', '备礼']).prefault('静待'),
  当前目标: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  幕后进度: z.coerce.number().transform(v => Math.max(0, Number(v) || 0)).prefault(0),
  最近异动: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  上次显化轮次: z.coerce.number().transform(v => Math.max(0, Number(v) || 0)).prefault(0),
  情缘归属: z.literal('{{user}}').prefault('{{user}}'),
  他缘许可: z.literal(false).prefault(false),
  纯爱锁: z.literal(true).prefault(true),
});

const EventLogSchema = z.object({
  回合: z.coerce.number().transform(v => Math.max(0, Number(v) || 0)).prefault(0),
  角色: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  标题: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  风闻: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  状态: z.coerce.string().transform(v => String(v).trim()).prefault(''),
});

const EngineStateSchema = z.object({
  版本: z.coerce.string().transform(v => String(v).trim()).prefault('0.1.0'),
  回合计数: z.coerce.number().transform(v => Math.max(0, Number(v) || 0)).prefault(0),
  上次处理消息键: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  当前风闻: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  当前机遇标题: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  角色状态: z.record(z.string(), ActorStateSchema).prefault({}),
  最近异动: z.array(EventLogSchema).prefault([]),
});

type EngineState = z.infer<typeof EngineStateSchema>;
type ParsedData = ReturnType<typeof Schema.parse>;
type ActorState = z.infer<typeof ActorStateSchema>;

export interface SurfacedEvolutionHook {
  actorName: string;
  title: string;
  type: '红颜' | '修炼' | '探索';
  source: string;
  description: string;
  reward: string;
  risk: string;
  rumor: string;
  nextState: ActorState['幕后状态'];
  nextTarget: string;
  progressDelta: number;
  priority: number;
}

export interface RuntimeSnapshot {
  回合计数: number;
  当前风闻: string;
  当前机遇标题: string;
  最近异动: Array<z.infer<typeof EventLogSchema>>;
  角色状态: Record<string, ActorState>;
}

let isProcessing = false;
let offHandlers: EventOnReturn[] = [];

function readChatState(): EngineState {
  try {
    const chatVariables = getVariables({ type: 'chat' });
    return EngineStateSchema.parse(_.get(chatVariables, CHAT_STATE_KEY, {}));
  } catch (e) {
    console.warn(`[${SCRIPT_NAME}] 读取聊天级幕后状态失败，回退默认值`, e);
    return EngineStateSchema.parse({});
  }
}

function writeChatState(state: EngineState) {
  const chatVariables = getVariables({ type: 'chat' });
  _.set(chatVariables, CHAT_STATE_KEY, klona(state));
  replaceVariables(chatVariables, { type: 'chat' });
}

function buildMessageKey(chatId: string, messageId: number) {
  return `${chatId}:${messageId}`;
}

function getLatestAssistantMessage() {
  const latest = getChatMessages(-1)[0];
  if (!latest || latest.role !== 'assistant' || latest.is_hidden) return null;
  return latest;
}

function readLatestMvuData(messageId: number): ParsedData | null {
  try {
    const raw = Mvu.getMvuData({ type: 'message', message_id: messageId });
    const statData = _.get(raw, 'stat_data', null);
    if (!statData) return null;
    return Schema.parse(statData);
  } catch (e) {
    console.warn(`[${SCRIPT_NAME}] 读取 MVU 数据失败`, e);
    return null;
  }
}

async function waitForLatestMvuData(messageId: number, timeoutMs = 2600): Promise<ParsedData | null> {
  const startTime = Date.now();

  while (Date.now() - startTime < timeoutMs) {
    const parsed = readLatestMvuData(messageId);
    if (parsed) return parsed;
    await new Promise(resolve => window.setTimeout(resolve, 120));
  }

  return readLatestMvuData(messageId);
}

function initializeActorState(name: string, actor: ParsedData['红颜'][string]): ActorState {
  const threshold = actor.突破阈值 || 100;
  const ratio = threshold > 0 ? actor.修为 / threshold : 0;

  if ((actor.状态 || '').includes('瓶颈') || ratio >= 0.78) {
    return ActorStateSchema.parse({
      幕后状态: '闭关',
      当前目标: '稳固境界',
      最近异动: `${name}正闭关稳境`,
    });
  }

  return ActorStateSchema.parse({
    幕后状态: actor.好感度 >= 50 ? '备礼' : '查案',
    当前目标: actor.好感度 >= 50 ? '待与你相见' : '追查旧线',
    最近异动: actor.好感度 >= 50 ? `${name}似在等你抽身一见` : `${name}正暗查旧线`,
  });
}

function pickActiveActor(data: ParsedData, state: EngineState): { name: string; actor: ParsedData['红颜'][string]; actorState: ActorState } | null {
  const entries = Object.entries(data.红颜 || {});
  if (entries.length === 0) return null;

  const scored = entries
    .map(([name, actor]) => {
      const actorState = state.角色状态[name] ?? initializeActorState(name, actor);
      let score = actor.好感度;
      if (actorState.幕后状态 === '待护法') score += 50;
      if ((actor.关系 || '').includes('未婚') || (actor.关系 || '').includes('道侣')) score += 25;
      if ((actor.状态 || '').includes('瓶颈')) score += 20;
      if (actorState.幕后状态 === '查案') score += 8;
      return { name, actor, actorState, score };
    })
    .sort((a, b) => b.score - a.score);

  return scored[0] ?? null;
}

function hashString(input: string): number {
  let hash = 0;
  for (let i = 0; i < input.length; i += 1) {
    hash = (hash * 31 + input.charCodeAt(i)) >>> 0;
  }
  return hash;
}

function buildCandidates(
  actorName: string,
  actor: ParsedData['红颜'][string],
  actorState: ActorState,
  data: ParsedData,
): SurfacedEvolutionHook[] {
  const currentRegion = data.本尊?.行踪?.当前区域 || '外域';
  const realm = actor.境界描述 || '当前境界';
  const threshold = actor.突破阈值 || 100;
  const ratio = threshold > 0 ? actor.修为 / threshold : 0;
  const nearBreakthrough = ratio >= 0.78 || (actor.状态 || '').includes('瓶颈');

  const commonMeeting: SurfacedEvolutionHook = {
    actorName,
    title: `赴约见${actorName}`,
    type: '红颜',
    source: GENERATED_SOURCE,
    description: `${actorName}近日似有话欲与你说，若抽身赴约，或能探得她此刻心意与近况。`,
    reward: '可拉近情谊，并知晓她眼下所思所念',
    risk: '低，几无外患',
    rumor: `${actorName}近来屡屡留意你的行踪，似在静候你抽空一见。`,
    nextState: '备礼',
    nextTarget: '待与你相见',
    progressDelta: 1,
    priority: 3,
  };

  const guardBreakthrough: SurfacedEvolutionHook = {
    actorName,
    title: `为${actorName}护法`,
    type: '红颜',
    source: GENERATED_SOURCE,
    description: `${actorName}正在稳固${realm}修为，灵台微乱，若得你在旁护持，当可少走岔路。`,
    reward: '有望稳住其修为根基，并进一步增进信赖',
    risk: '中低，或有外敌窥伺闭关之所',
    rumor: `${actorName}近来多在静室稳境，似在破关前格外想见你。`,
    nextState: '待护法',
    nextTarget: '稳固境界',
    progressDelta: 1,
    priority: 5,
  };

  const investigateClue: SurfacedEvolutionHook = {
    actorName,
    title: `接应${actorName}`,
    type: '红颜',
    source: GENERATED_SOURCE,
    description: `${actorName}循着旧案余痕，在${currentRegion}附近暗查线索，却似已惊动暗中窥视之人。`,
    reward: '可得旧案线索，并让她更信你可托付后背',
    risk: '中等，途中或有伏击与窥探',
    rumor: `${actorName}近来常在${currentRegion}一带出没，像是在追索某段未竟旧事。`,
    nextState: '查案',
    nextTarget: '追查旧线',
    progressDelta: 1,
    priority: 4,
  };

  const gatherMedicine: SurfacedEvolutionHook = {
    actorName,
    title: `为${actorName}寻药`,
    type: '修炼',
    source: GENERATED_SOURCE,
    description: `${actorName}近日气息略显不稳，似缺一味温养神魂之药，你可趁机为她寻来。`,
    reward: '可助她稳住状态，并为后续共修铺路',
    risk: '中等，采药途中可能遭遇妖物或争抢',
    rumor: `${actorName}似在暗寻一味养神之药，却不愿轻易开口求助。`,
    nextState: '觅药',
    nextTarget: '寻得养神之药',
    progressDelta: 1,
    priority: 4,
  };

  const studyRemnant: SurfacedEvolutionHook = {
    actorName,
    title: `与${actorName}共参残卷`,
    type: '修炼',
    source: GENERATED_SOURCE,
    description: `${actorName}似得了一页残卷，正缺一位能与她共参其中玄意的人。`,
    reward: '或可共得感悟，并推进她的修行进境',
    risk: '中低，参悟失败时可能伤神耗气',
    rumor: `${actorName}手中似新得残卷一页，近来偶有沉思出神之态。`,
    nextState: '闭关',
    nextTarget: '参悟残卷',
    progressDelta: 1,
    priority: 4,
  };

  switch (actorState.幕后状态) {
    case '闭关':
      return nearBreakthrough ? [guardBreakthrough, studyRemnant, commonMeeting] : [studyRemnant, commonMeeting, gatherMedicine];
    case '查案':
      return [investigateClue, commonMeeting, gatherMedicine];
    case '养伤':
      return [gatherMedicine, commonMeeting, guardBreakthrough];
    case '觅药':
      return [gatherMedicine, investigateClue, commonMeeting];
    case '待护法':
      return [guardBreakthrough, studyRemnant, commonMeeting];
    case '备礼':
      return [commonMeeting, studyRemnant, investigateClue];
    case '静待':
    default:
      return nearBreakthrough ? [guardBreakthrough, commonMeeting, investigateClue] : [investigateClue, commonMeeting, studyRemnant];
  }
}

function chooseCandidate(candidates: SurfacedEvolutionHook[], messageKey: string, actorName: string): SurfacedEvolutionHook {
  const index = hashString(`${messageKey}:${actorName}`) % candidates.length;
  return klona(candidates[index]);
}

function updateActorState(previous: ActorState, hook: SurfacedEvolutionHook, round: number): ActorState {
  return ActorStateSchema.parse({
    ...previous,
    幕后状态: hook.nextState,
    当前目标: hook.nextTarget,
    幕后进度: previous.幕后状态 === hook.nextState ? previous.幕后进度 + hook.progressDelta : hook.progressDelta,
    最近异动: hook.rumor,
    上次显化轮次: round,
  });
}

function buildRuntimeSnapshot(state: EngineState): RuntimeSnapshot {
  return {
    回合计数: state.回合计数,
    当前风闻: state.当前风闻,
    当前机遇标题: state.当前机遇标题,
    最近异动: state.最近异动,
    角色状态: state.角色状态,
  };
}

function emitRuntimeSnapshot(snapshot: RuntimeSnapshot): RuntimeSnapshot {
  window.dispatchEvent(
    new CustomEvent<RuntimeSnapshot>(RUNTIME_SNAPSHOT_EVENT, {
      detail: klona(snapshot),
    }),
  );
  return snapshot;
}

export function getRuntimeSnapshot(): RuntimeSnapshot {
  return buildRuntimeSnapshot(readChatState());
}

export function onRuntimeSnapshotChange(listener: (snapshot: RuntimeSnapshot) => void): () => void {
  const handler = (event: Event) => {
    listener((event as CustomEvent<RuntimeSnapshot>).detail);
  };
  window.addEventListener(RUNTIME_SNAPSHOT_EVENT, handler);
  return () => window.removeEventListener(RUNTIME_SNAPSHOT_EVENT, handler);
}

function finishWithSnapshot(state: EngineState): RuntimeSnapshot {
  return emitRuntimeSnapshot(buildRuntimeSnapshot(state));
}

export async function runEvolution(options?: { force?: boolean; from?: string; showToast?: boolean }) {
  if (isProcessing) return emitRuntimeSnapshot(getRuntimeSnapshot());

  const settings = readSettings();
  if (!settings.enabled) return emitRuntimeSnapshot(getRuntimeSnapshot());
  if (!settings.auto_evolve && !options?.force) return emitRuntimeSnapshot(getRuntimeSnapshot());

  const latest = getLatestAssistantMessage();
  if (!latest) return emitRuntimeSnapshot(getRuntimeSnapshot());

  const chatId = SillyTavern.getCurrentChatId();
  const messageKey = buildMessageKey(chatId, latest.message_id);

  const state = readChatState();
  if (state.上次处理消息键 === messageKey && !options?.force) {
    return finishWithSnapshot(state);
  }

  isProcessing = true;

  try {
    const parsed = await waitForLatestMvuData(latest.message_id);
    if (!parsed) return finishWithSnapshot(state);

    state.回合计数 += 1;
    state.上次处理消息键 = messageKey;

    if (!options?.force && state.回合计数 % settings.turn_interval !== 0) {
      writeChatState(state);
      return finishWithSnapshot(state);
    }

    const active = pickActiveActor(parsed, state);
    if (!active) {
      writeChatState(state);
      return finishWithSnapshot(state);
    }

    const previousActorState = state.角色状态[active.name] ?? initializeActorState(active.name, active.actor);
    const candidate = chooseCandidate(buildCandidates(active.name, active.actor, previousActorState, parsed), messageKey, active.name);
    const enhanced = await maybeEnhanceHook(candidate, settings);
    const finalHook: SurfacedEvolutionHook = {
      ...candidate,
      ...enhanced,
    };

    state.角色状态[active.name] = updateActorState(previousActorState, finalHook, state.回合计数);
    state.当前风闻 = finalHook.rumor;
    state.当前机遇标题 = finalHook.title;
    state.最近异动 = [
      {
        回合: state.回合计数,
        角色: active.name,
        标题: finalHook.title,
        风闻: finalHook.rumor,
        状态: finalHook.nextState,
      },
      ...state.最近异动,
    ].slice(0, 8);

    writeChatState(state);

    if (settings.show_toasts || options?.showToast) {
      toastr.success(`${active.name}有了新的幕后异动：${finalHook.title}`, SCRIPT_NAME);
    }

    console.info(`[${SCRIPT_NAME}] 已推进幕后演化`, {
      消息楼层: latest.message_id,
      角色: active.name,
      标题: finalHook.title,
      状态: finalHook.nextState,
      来源: options?.from ?? 'auto',
    });

    return finishWithSnapshot(state);
  } finally {
    isProcessing = false;
  }
}

export async function runManualEvolution() {
  return runEvolution({ force: true, from: 'manual', showToast: true });
}

export async function initializeEvolutionEngine() {
  if (offHandlers.length > 0) return;

  await waitGlobalInitialized('Mvu');
  console.info(`[${SCRIPT_NAME}] 已加载，纯爱锁永久开启`);
  emitRuntimeSnapshot(getRuntimeSnapshot());

  offHandlers = [
    eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, async () => {
      await runEvolution({ from: 'mvu' });
    }),
    eventOn(tavern_events.MESSAGE_RECEIVED, async () => {
      await new Promise(resolve => window.setTimeout(resolve, 320));
      await runEvolution({ from: 'message' });
    }),
    eventOn(tavern_events.CHAT_CHANGED, async () => {
      await new Promise(resolve => window.setTimeout(resolve, 400));
      await runEvolution({ from: 'chat-changed' });
    }),
  ];

  await runEvolution({ from: 'startup' });
}

export function destroyEvolutionEngine() {
  offHandlers.forEach(off => off.stop());
  offHandlers = [];
}
