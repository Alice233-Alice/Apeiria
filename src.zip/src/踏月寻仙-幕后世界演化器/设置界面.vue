<template>
  <div class="world-evolution-settings">
    <div class="inline-drawer">
      <div class="inline-drawer-toggle inline-drawer-header">
        <b>幕后世界演化器</b>
        <div class="inline-drawer-icon fa-solid fa-circle-chevron-down down"></div>
      </div>
      <div class="inline-drawer-content">
        <div class="settings-card version-card">
          <div class="card-title">当前状态</div>
          <div v-if="runtime" class="status-meta">
            已演化 {{ runtime.回合计数 }} 次
          </div>
          <div v-if="runtime?.当前机遇标题" class="status-line">
            当前机遇：{{ runtime.当前机遇标题 }}
          </div>
          <div v-if="runtime?.当前风闻" class="status-line">
            当前风闻：{{ runtime.当前风闻 }}
          </div>
          <div v-if="lastEvent" class="status-line">
            最新异动：{{ lastEvent.角色 }} · {{ lastEvent.标题 }}
          </div>
        </div>

        <div class="settings-card">
          <div class="card-title">本地演化</div>
          <label class="toggle-row">
            <input v-model="settings.enabled" type="checkbox" />
            <span>启用幕后演化</span>
          </label>
          <label class="toggle-row">
            <input v-model="settings.auto_evolve" type="checkbox" />
            <span>自动演化</span>
          </label>
          <label class="toggle-row">
            <input v-model="settings.show_toasts" type="checkbox" />
            <span>演化时通知</span>
          </label>
          <label class="field-row">
            <span>每隔几回合演化</span>
            <input v-model.number="settings.turn_interval" class="text_pole" type="number" min="1" max="9" />
          </label>
          <p class="field-tip">这部分目前只保留实验性后台推演，不再接入测试版状态栏。</p>
        </div>

        <div class="settings-card">
          <div class="card-title">增强 API</div>
          <label class="toggle-row">
            <input v-model="settings.api_enabled" type="checkbox" />
            <span>启用额外模型润色</span>
          </label>
          <label class="field-row">
            <span>API 地址</span>
            <input v-model="settings.api_base_url" class="text_pole" type="text" placeholder="https://example.com/v1" />
          </label>
          <label class="field-row">
            <span>API 密钥</span>
            <input v-model="settings.api_key" class="text_pole" type="password" placeholder="可留空" />
          </label>
          <label class="field-row">
            <span>模型名称</span>
            <input v-model="settings.api_model" class="text_pole" type="text" placeholder="qwen / gemini / gpt-4o-mini..." />
          </label>
          <label class="field-row">
            <span>超时毫秒</span>
            <input v-model.number="settings.api_timeout_ms" class="text_pole" type="number" min="3000" max="60000" />
          </label>
          <p class="field-tip">不填也能正常演化，额外模型只负责润色推演文案。</p>
        </div>

        <div class="settings-card">
          <div class="card-title">手动控制</div>
          <div class="button-row">
            <input class="menu_button" type="button" value="立即演化一次" :disabled="busy" @click="handleManualRun" />
            <input class="menu_button" type="button" value="刷新状态" :disabled="busy" @click="refreshRuntime" />
          </div>
          <div v-if="runtime?.最近异动?.length" class="recent-block">
            <div class="recent-title">最近异动</div>
            <div v-for="item in runtime.最近异动.slice(0, 4)" :key="`${item.回合}-${item.角色}-${item.标题}`" class="recent-item">
              <div class="recent-main">{{ item.角色 }} · {{ item.标题 }}</div>
              <div class="recent-sub">{{ item.风闻 }}</div>
            </div>
          </div>
        </div>

        <hr class="sysHR" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { getRuntimeSnapshot, onRuntimeSnapshotChange, runManualEvolution } from './engine';
import { useSettingsStore } from './settings';

const { settings } = storeToRefs(useSettingsStore());

const busy = ref(false);
const runtime = ref(getRuntimeSnapshot());
const lastEvent = computed(() => runtime.value?.最近异动?.[0] ?? null);

let stopRuntimeSync = () => {};

async function refreshRuntime() {
  runtime.value = getRuntimeSnapshot();
}

async function handleManualRun() {
  if (busy.value) return;
  busy.value = true;
  try {
    runtime.value = await runManualEvolution();
  } finally {
    busy.value = false;
  }
}

onMounted(() => {
  void refreshRuntime();
  stopRuntimeSync = onRuntimeSnapshotChange(snapshot => {
    runtime.value = snapshot;
  });
});

onUnmounted(() => {
  stopRuntimeSync();
});
</script>

<style scoped>
.world-evolution-settings {
  color: var(--SmartThemeBodyColor);
}

.settings-card {
  margin: 10px 0;
  padding: 14px;
  border: 1px solid color-mix(in srgb, var(--SmartThemeBorderColor) 70%, transparent);
  border-radius: 12px;
  background:
    linear-gradient(180deg, color-mix(in srgb, var(--SmartThemeBlurTintColor) 86%, transparent) 0%, transparent 100%),
    color-mix(in srgb, var(--SmartThemeQuoteColor) 8%, transparent);
}

.version-card {
  border-color: color-mix(in srgb, #e7b7c7 28%, var(--SmartThemeBorderColor));
}

.card-title {
  margin-bottom: 10px;
  font-weight: 700;
}

.toggle-row,
.field-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin: 10px 0;
}

.toggle-row input[type='checkbox'] {
  margin-right: 8px;
}

.field-row span {
  flex: 0 0 140px;
}

.field-row .text_pole {
  flex: 1 1 auto;
}

.status-meta,
.status-line,
.field-tip,
.recent-sub {
  opacity: 0.9;
}

.button-row {
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.recent-block {
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px dashed color-mix(in srgb, var(--SmartThemeBorderColor) 70%, transparent);
}

.recent-title {
  margin-bottom: 8px;
  font-weight: 700;
}

.recent-item {
  padding: 10px 0;
  border-bottom: 1px solid color-mix(in srgb, var(--SmartThemeBorderColor) 38%, transparent);
}

.recent-item:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.recent-main {
  font-weight: 600;
}
</style>
