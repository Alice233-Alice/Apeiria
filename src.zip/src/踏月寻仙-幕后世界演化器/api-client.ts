import type { SurfacedEvolutionHook } from './engine';
import type { EvolutionSettings } from './settings';

const EnhancementSchema = z
  .object({
    风闻: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    描述: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    回报预期: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    风险评估: z.coerce.string().transform(v => String(v).trim()).prefault(''),
  })
  .prefault({});

const FORBIDDEN_PHRASES = [
  '联姻',
  '改嫁',
  '相亲',
  '婚配',
  '他人道侣',
  '双修他人',
  '失身',
  '被辱',
  '纳妾',
  '旁人怀中',
];

function extractJson(content: string): string | null {
  const fenced = content.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenced?.[1]) return fenced[1].trim();

  const start = content.indexOf('{');
  const end = content.lastIndexOf('}');
  if (start >= 0 && end > start) {
    return content.slice(start, end + 1).trim();
  }
  return null;
}

function containsForbiddenText(payload: string): boolean {
  return FORBIDDEN_PHRASES.some(phrase => payload.includes(phrase));
}

export async function maybeEnhanceHook(
  hook: SurfacedEvolutionHook,
  settings: EvolutionSettings,
): Promise<Partial<SurfacedEvolutionHook> | null> {
  if (!settings.api_enabled || !settings.api_base_url || !settings.api_model) return null;

  const endpoint = `${settings.api_base_url.replace(/\/+$/, '')}/chat/completions`;
  const payload = {
    model: settings.api_model,
    temperature: 0.35,
    messages: [
      {
        role: 'system',
        content:
          '你是修仙世界的幕后演化文案润色器。只能润色已给定的安全事件，不得新增第三者感情线、联姻、失身、他人双修等内容。只返回 JSON 对象，字段限 风闻/描述/回报预期/风险评估。',
      },
      {
        role: 'user',
        content: JSON.stringify({
          角色: hook.actorName,
          标题: hook.title,
          风闻: hook.rumor,
          描述: hook.description,
          回报预期: hook.reward,
          风险评估: hook.risk,
        }),
      },
    ],
  };

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), settings.api_timeout_ms);

  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(settings.api_key ? { Authorization: `Bearer ${settings.api_key}` } : {}),
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }

    const data = await response.json();
    const content = _.get(data, 'choices[0].message.content', '');
    if (!content || typeof content !== 'string') return null;

    const jsonText = extractJson(content);
    if (!jsonText) return null;

    const enhanced = EnhancementSchema.parse(JSON.parse(jsonText));
    const mergedText = `${enhanced.风闻} ${enhanced.描述} ${enhanced.回报预期} ${enhanced.风险评估}`;
    if (containsForbiddenText(mergedText)) return null;

    return {
      rumor: enhanced.风闻 || hook.rumor,
      description: enhanced.描述 || hook.description,
      reward: enhanced.回报预期 || hook.reward,
      risk: enhanced.风险评估 || hook.risk,
    };
  } catch (e) {
    console.warn('[幕后世界演化器] 增强 API 调用失败，回退本地模板', e);
    return null;
  } finally {
    window.clearTimeout(timeout);
  }
}
