<template>
  <div v-if="settings.show_floating_panel" class="evo-float-shell">
    <button v-if="collapsed" type="button" class="evo-float-pill" :class="{ 'is-fresh': livePulse }" @click="collapsed = false">
      <span class="evo-float-pill-dot"></span>
      <span class="evo-float-pill-label">幕后天机</span>
      <span class="evo-float-pill-count">{{ badgeText }}</span>
    </button>

    <section v-else class="evo-float-panel" :class="{ 'is-fresh': livePulse, 'is-paused': !settings.enabled }">
      <div class="evo-float-glow"></div>

      <header class="evo-float-header">
        <div class="evo-float-header-copy">
          <div class="evo-float-eyebrow">TAYUE LIVE ENGINE</div>
          <div class="evo-float-title-row">
            <h3>幕后世界演化器</h3>
            <span class="evo-float-badge">{{ statusText }}</span>
          </div>
        </div>

        <div class="evo-float-actions">
          <button type="button" class="evo-icon-button" title="刷新状态" @click="refreshRuntime">
            <i class="fa-solid fa-rotate-right"></i>
          </button>
          <button type="button" class="evo-icon-button" title="收起面板" @click="collapsed = true">
            <i class="fa-solid fa-minus"></i>
          </button>
        </div>
      </header>

      <div class="evo-float-main">
        <section class="evo-spotlight">
          <div class="evo-section-label">当前机遇</div>
          <div class="evo-spotlight-title">{{ runtime.当前机遇标题 || '幕后天机暂未显化' }}</div>
          <div class="evo-spotlight-rumor">{{ runtime.当前风闻 || fallbackRumor }}</div>
        </section>

        <section class="evo-stat-grid">
          <div class="evo-stat-card">
            <span>演化回合</span>
            <strong>{{ runtime.回合计数 }}</strong>
          </div>
          <div class="evo-stat-card">
            <span>最近主角</span>
            <strong>{{ leadActor }}</strong>
          </div>
        </section>

        <section class="evo-recent">
          <div class="evo-section-label">最近异动</div>
          <div v-if="runtime.最近异动.length === 0" class="evo-empty-state">
            等待新的回复触发幕后演化。
          </div>
          <div
            v-for="item in runtime.最近异动.slice(0, 3)"
            :key="`${item.回合}-${item.角色}-${item.标题}`"
            class="evo-recent-item"
          >
            <div class="evo-recent-top">
              <span class="evo-recent-name">{{ item.角色 }}</span>
              <span class="evo-recent-turn">第 {{ item.回合 }} 轮</span>
            </div>
            <div class="evo-recent-title">{{ item.标题 }}</div>
            <div class="evo-recent-rumor">{{ item.风闻 }}</div>
          </div>
        </section>
      </div>

      <footer class="evo-float-footer">
        <button type="button" class="evo-primary-button" :disabled="busy" @click="handleManualRun">
          <i class="fa-solid fa-wand-magic-sparkles"></i>
          <span>{{ busy ? '推演中...' : '立即推演一次' }}</span>
        </button>

        <label class="evo-toggle-chip">
          <input v-model="settings.auto_evolve" type="checkbox" />
          <span>自动</span>
        </label>

        <button type="button" class="evo-ghost-button" @click="settings.show_floating_panel = false">
          隐藏
        </button>
      </footer>
    </section>
  </div>
</template>

<script setup lang="ts">
import { storeToRefs } from 'pinia';
import { getRuntimeSnapshot, onRuntimeSnapshotChange, runManualEvolution, type RuntimeSnapshot } from './engine';
import { useSettingsStore } from './settings';

const { settings } = storeToRefs(useSettingsStore());

const busy = ref(false);
const collapsed = ref(false);
const livePulse = ref(false);
const runtime = ref<RuntimeSnapshot>(getRuntimeSnapshot());

const leadActor = computed(() => runtime.value.最近异动[0]?.角色 || '未定');
const statusText = computed(() => {
  if (!settings.value.enabled) return '已暂停';
  return settings.value.auto_evolve ? '自动演化中' : '仅手动演化';
});
const fallbackRumor = computed(() => {
  if (!settings.value.enabled) {
    return '脚本已暂停，恢复后才会继续显化幕后动向。';
  }
  return '等待下一条回复触发世界暗线，让幕后角色真正活起来。';
});
const badgeText = computed(() => runtime.value.最近异动[0]?.角色 || `${runtime.value.回合计数} 轮`);

let pulseTimer: number | undefined;
let stopRuntimeSync = () => {};

function applySnapshot(snapshot: RuntimeSnapshot, animate = true) {
  runtime.value = snapshot;
  if (!animate) return;

  livePulse.value = true;
  if (pulseTimer !== undefined) {
    window.clearTimeout(pulseTimer);
  }
  pulseTimer = window.setTimeout(() => {
    livePulse.value = false;
  }, 1800);
}

async function refreshRuntime() {
  applySnapshot(getRuntimeSnapshot(), false);
}

async function handleManualRun() {
  if (busy.value) return;
  busy.value = true;
  try {
    collapsed.value = false;
    applySnapshot(await runManualEvolution());
  } finally {
    busy.value = false;
  }
}

onMounted(() => {
  applySnapshot(getRuntimeSnapshot(), false);
  stopRuntimeSync = onRuntimeSnapshotChange(snapshot => {
    applySnapshot(snapshot);
  });
});

onUnmounted(() => {
  stopRuntimeSync();
  if (pulseTimer !== undefined) {
    window.clearTimeout(pulseTimer);
  }
});
</script>

<style scoped>
.evo-float-shell {
  position: fixed;
  right: 18px;
  bottom: 18px;
  z-index: 3800;
  width: min(380px, calc(100vw - 24px));
  pointer-events: none;
}

.evo-float-pill,
.evo-float-panel {
  pointer-events: auto;
}

.evo-float-pill {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  margin-left: auto;
  padding: 12px 16px;
  border: 1px solid rgba(255, 214, 153, 0.32);
  border-radius: 999px;
  color: #fff4de;
  background:
    radial-gradient(circle at top left, rgba(255, 208, 120, 0.22), transparent 44%),
    linear-gradient(135deg, rgba(22, 24, 39, 0.96), rgba(49, 23, 17, 0.94));
  box-shadow: 0 16px 34px rgba(0, 0, 0, 0.28);
  cursor: pointer;
}

.evo-float-pill.is-fresh {
  box-shadow: 0 18px 40px rgba(229, 153, 73, 0.34);
}

.evo-float-pill-dot {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: linear-gradient(180deg, #ffd48a, #ff8a4c);
  box-shadow: 0 0 0 6px rgba(255, 186, 102, 0.14);
}

.evo-float-pill-label {
  font-size: 13px;
  letter-spacing: 0.18em;
}

.evo-float-pill-count {
  padding: 2px 9px;
  border-radius: 999px;
  background: rgba(255, 236, 206, 0.12);
  font-size: 12px;
}

.evo-float-panel {
  position: relative;
  overflow: hidden;
  padding: 18px;
  border: 1px solid rgba(255, 215, 150, 0.22);
  border-radius: 24px;
  color: #f7ecdd;
  background:
    radial-gradient(circle at top left, rgba(255, 198, 92, 0.16), transparent 38%),
    radial-gradient(circle at bottom right, rgba(154, 66, 41, 0.24), transparent 32%),
    linear-gradient(180deg, rgba(17, 20, 31, 0.98), rgba(28, 18, 16, 0.96));
  box-shadow:
    0 26px 60px rgba(0, 0, 0, 0.42),
    inset 0 1px 0 rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(10px);
}

.evo-float-panel.is-fresh {
  border-color: rgba(255, 213, 138, 0.44);
  box-shadow:
    0 26px 68px rgba(0, 0, 0, 0.46),
    0 0 0 1px rgba(255, 191, 112, 0.14);
}

.evo-float-panel.is-paused {
  filter: saturate(0.72);
}

.evo-float-glow {
  position: absolute;
  inset: auto -80px -110px auto;
  width: 220px;
  height: 220px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(255, 151, 83, 0.18), transparent 64%);
  pointer-events: none;
}

.evo-float-header,
.evo-float-footer,
.evo-float-main {
  position: relative;
  z-index: 1;
}

.evo-float-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 16px;
}

.evo-float-header-copy {
  min-width: 0;
}

.evo-float-eyebrow {
  margin-bottom: 6px;
  color: rgba(255, 215, 163, 0.72);
  font-size: 11px;
  letter-spacing: 0.24em;
}

.evo-float-title-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 10px;
}

.evo-float-title-row h3 {
  margin: 0;
  font-size: 22px;
  font-weight: 700;
  line-height: 1.1;
}

.evo-float-badge {
  padding: 5px 10px;
  border: 1px solid rgba(255, 226, 176, 0.18);
  border-radius: 999px;
  color: #ffe3bd;
  font-size: 12px;
  background: rgba(255, 248, 234, 0.05);
}

.evo-float-actions {
  display: flex;
  gap: 8px;
}

.evo-icon-button,
.evo-ghost-button,
.evo-primary-button {
  border: none;
  cursor: pointer;
}

.evo-icon-button {
  width: 34px;
  height: 34px;
  border-radius: 12px;
  color: #ffe8c5;
  background: rgba(255, 247, 232, 0.08);
}

.evo-icon-button:hover {
  background: rgba(255, 247, 232, 0.14);
}

.evo-float-main {
  display: grid;
  gap: 14px;
  margin-top: 16px;
}

.evo-spotlight,
.evo-recent,
.evo-stat-card {
  border: 1px solid rgba(255, 228, 185, 0.12);
  background: rgba(255, 249, 238, 0.035);
}

.evo-spotlight {
  padding: 14px 14px 15px;
  border-radius: 18px;
}

.evo-section-label {
  margin-bottom: 9px;
  color: rgba(255, 223, 183, 0.72);
  font-size: 11px;
  letter-spacing: 0.16em;
}

.evo-spotlight-title {
  margin-bottom: 8px;
  color: #fff5e6;
  font-size: 18px;
  font-weight: 700;
  line-height: 1.25;
}

.evo-spotlight-rumor {
  color: rgba(255, 238, 214, 0.86);
  font-size: 13px;
  line-height: 1.65;
}

.evo-stat-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: 12px;
}

.evo-stat-card {
  padding: 13px 14px;
  border-radius: 16px;
}

.evo-stat-card span {
  display: block;
  margin-bottom: 8px;
  color: rgba(255, 218, 174, 0.72);
  font-size: 12px;
}

.evo-stat-card strong {
  color: #fff5e6;
  font-size: 20px;
  font-weight: 700;
}

.evo-recent {
  padding: 14px;
  border-radius: 18px;
}

.evo-empty-state {
  padding: 12px 0 2px;
  color: rgba(255, 235, 208, 0.74);
  font-size: 13px;
}

.evo-recent-item {
  padding: 11px 0;
  border-bottom: 1px solid rgba(255, 227, 185, 0.1);
}

.evo-recent-item:last-child {
  padding-bottom: 0;
  border-bottom: none;
}

.evo-recent-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  margin-bottom: 6px;
}

.evo-recent-name {
  color: #ffdca9;
  font-weight: 700;
}

.evo-recent-turn {
  color: rgba(255, 224, 183, 0.64);
  font-size: 12px;
}

.evo-recent-title {
  margin-bottom: 4px;
  color: #fff2db;
  font-weight: 600;
}

.evo-recent-rumor {
  color: rgba(255, 236, 212, 0.78);
  font-size: 13px;
  line-height: 1.55;
}

.evo-float-footer {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 16px;
}

.evo-primary-button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 10px;
  flex: 1 1 auto;
  padding: 12px 16px;
  border-radius: 16px;
  color: #1d120e;
  font-weight: 700;
  background: linear-gradient(135deg, #ffd38a, #ff9d61);
  box-shadow: 0 12px 28px rgba(255, 151, 88, 0.25);
}

.evo-primary-button:disabled {
  opacity: 0.7;
  cursor: wait;
}

.evo-toggle-chip {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 0 12px;
  height: 44px;
  border: 1px solid rgba(255, 225, 179, 0.14);
  border-radius: 14px;
  background: rgba(255, 248, 236, 0.04);
}

.evo-toggle-chip input {
  margin: 0;
}

.evo-ghost-button {
  height: 44px;
  padding: 0 14px;
  border-radius: 14px;
  color: #ffe7c1;
  background: rgba(255, 248, 236, 0.06);
}

@media (max-width: 700px) {
  .evo-float-shell {
    right: 12px;
    bottom: 12px;
    width: calc(100vw - 24px);
  }

  .evo-float-panel {
    padding: 16px;
    border-radius: 20px;
  }

  .evo-float-title-row h3 {
    font-size: 20px;
  }

  .evo-float-footer {
    flex-wrap: wrap;
  }

  .evo-primary-button {
    width: 100%;
  }
}
</style>
