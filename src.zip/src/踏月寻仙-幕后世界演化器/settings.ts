export const EvolutionSettingsSchema = z
  .object({
    enabled: z.boolean().prefault(true),
    auto_evolve: z.boolean().prefault(true),
    turn_interval: z.coerce.number().transform(v => _.clamp(Number(v) || 1, 1, 9)).prefault(1),
    inject_opportunities: z.boolean().prefault(true),
    max_generated_hooks: z.coerce.number().transform(v => _.clamp(Number(v) || 1, 1, 3)).prefault(1),
    show_toasts: z.boolean().prefault(false),
    api_enabled: z.boolean().prefault(false),
    api_base_url: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    api_key: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    api_model: z.coerce.string().transform(v => String(v).trim()).prefault(''),
    api_timeout_ms: z.coerce.number().transform(v => _.clamp(Number(v) || 15000, 3000, 60000)).prefault(15000),
  })
  .prefault({});

export type EvolutionSettings = z.infer<typeof EvolutionSettingsSchema>;

export function readSettings(): EvolutionSettings {
  return EvolutionSettingsSchema.parse(getVariables({ type: 'script', script_id: getScriptId() }));
}

export const useSettingsStore = defineStore('踏月寻仙-幕后世界演化器-settings', () => {
  const settings = ref(readSettings());

  watchEffect(() => {
    insertOrAssignVariables(klona(settings.value), { type: 'script', script_id: getScriptId() });
  });

  return { settings };
});
