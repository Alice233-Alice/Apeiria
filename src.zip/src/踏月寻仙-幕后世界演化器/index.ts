import { createScriptIdDiv, destroyScriptIdDiv, deteleportStyle, teleportStyle } from '@/util/script';
import { destroyEvolutionEngine, initializeEvolutionEngine } from './engine';
import 设置界面 from './设置界面.vue';

const pinia = createPinia();
const settingsApp = createApp(设置界面).use(pinia);

$(() => {
  errorCatched(async () => {
    const $settingsApp = createScriptIdDiv();

    $('#extensions_settings2').append($settingsApp);
    teleportStyle();
    settingsApp.mount($settingsApp[0]);

    await initializeEvolutionEngine();
    console.info('[幕后世界演化器] 扩展已加载');
  })();
});

$(window).on('pagehide', () => {
  destroyEvolutionEngine();
  settingsApp.unmount();
  deteleportStyle();
  destroyScriptIdDiv();
});
