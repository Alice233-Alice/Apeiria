﻿import { Schema } from '../踏月寻仙-测试版/schema';

const GUARD_INSTALLED_KEY = '__踏月寻仙_mvu_guard_installed__';
const DUAL_SOUL_CANONICAL_NAME = '虞汐颜';
const DUAL_SOUL_ALIASES = new Set(['虞汐', '虞颜']);
const pendingCompanionLevels = new Map<string, number>();
const pendingCompanionLibraryLevels = new Map<string, number>();

function normalizeCommandPath(rawPath: string): string {
  let path = String(rawPath || '').trim();
  if (!path) return path;

  if (path.startsWith('./')) {
    path = path.slice(1);
  }
  if (path.startsWith('/')) {
    path = path.replace(/^\/+/, '').replaceAll('/', '.');
  }

  path = path
    .replaceAll('：', ':')
    .replaceAll('。', '.')
    .replace(/\s+/g, '')
    .replace(/\.\.+/g, '.');

  const aliasMap: Record<string, string> = {
    世界地圖: '世界地图',
    危險度: '危险度',
    當前區域: '当前区域',
    所屬層級: '所属层级',
    當前處境: '当前处境',
    可參與機遇: '可参与机遇',
    任務列表: '任务列表',
  };

  for (const [from, to] of Object.entries(aliasMap)) {
    path = path.replaceAll(from, to);
  }

  if (!path.startsWith('stat_data.')) {
    const topLevelKeys = ['本尊', '世界地图', '世界图志', '任务列表', '红颜', '地点库', '可参与机遇', '当前处境', '难度系统', '_系统设置'];
    if (topLevelKeys.some(key => path === key || path.startsWith(`${key}.`))) {
      path = `stat_data.${path}`;
    }
  }

  return path;
}

function normalizeCompanionAliasPath(path: string): string {
  const companionMatch = path.match(/^stat_data\.红颜\.([^./]+)(?=\.|$)/);
  if (companionMatch && DUAL_SOUL_ALIASES.has(companionMatch[1])) {
    return path.replace(`stat_data.红颜.${companionMatch[1]}`, `stat_data.红颜.${DUAL_SOUL_CANONICAL_NAME}`);
  }

  const libraryMatch = path.match(/^stat_data\.红颜角色库\.([^./]+)(?=\.|$)/);
  if (libraryMatch && DUAL_SOUL_ALIASES.has(libraryMatch[1])) {
    return path.replace(`stat_data.红颜角色库.${libraryMatch[1]}`, `stat_data.红颜角色库.${DUAL_SOUL_CANONICAL_NAME}`);
  }

  return path;
}

function coerceByPath(path: string, value: unknown): unknown {
  if (path.endsWith('熟练度') && typeof value === 'string') {
    const v = value.trim();
    const unquoted = v.replace(/^["'“”‘’]+|["'“”‘’]+$/g, '');

    if (unquoted.includes('小成')) return '熟练';
    if (unquoted.includes('中成')) return '精通';
    if (unquoted.includes('大圆满')) return '圆满';
  }

  return value;
}

function rememberCompanionLevel(path: string, value: unknown): void {
  const level = Number(value);
  if (!Number.isFinite(level) || level < 1) return;
  const normalizedLevel = Math.floor(level);

  const companionMatch = path.match(/^stat_data\.红颜\.([^./]+)\.等级$/);
  if (companionMatch) {
    pendingCompanionLevels.set(companionMatch[1], normalizedLevel);
    return;
  }

  const libraryMatch = path.match(/^stat_data\.红颜角色库\.([^./]+)\.级$/);
  if (libraryMatch) {
    pendingCompanionLibraryLevels.set(libraryMatch[1], normalizedLevel);
  }
}

function applyPendingCompanionLevels(newVariables: Mvu.MvuData): void {
  for (const [name, level] of pendingCompanionLevels.entries()) {
    if (_.has(newVariables, `stat_data.红颜.${name}`)) {
      _.set(newVariables, `stat_data.红颜.${name}.等级`, level);
    }
  }

  for (const [name, level] of pendingCompanionLibraryLevels.entries()) {
    if (_.has(newVariables, `stat_data.红颜角色库.${name}`)) {
      _.set(newVariables, `stat_data.红颜角色库.${name}.级`, level);
    }
  }
}

function installGuard() {
  const globalRef = window as unknown as Record<string, unknown>;
  if (globalRef[GUARD_INSTALLED_KEY]) return;
  globalRef[GUARD_INSTALLED_KEY] = true;

  eventOn(Mvu.events.COMMAND_PARSED, (_variables: Mvu.MvuData, commands: Mvu.CommandInfo[]) => {
    for (const command of commands as Array<{ args?: unknown[] }>) {
      if (!Array.isArray(command.args) || command.args.length === 0) continue;

      const rawPath = String(command.args[0] ?? '');
      const normalizedPath = normalizeCompanionAliasPath(normalizeCommandPath(rawPath));
      if (normalizedPath && normalizedPath !== rawPath) {
        command.args[0] = normalizedPath;
      }

      if (command.args.length >= 2 && normalizedPath) {
        const rawValue = command.args[1];
        const normalizedValue = coerceByPath(normalizedPath, rawValue);
        if (!_.isEqual(rawValue, normalizedValue)) {
          command.args[1] = normalizedValue;
        }
        rememberCompanionLevel(normalizedPath, command.args[1]);
      }
    }
  });

  eventOn(Mvu.events.VARIABLE_UPDATE_ENDED, (newVariables: Mvu.MvuData) => {
    applyPendingCompanionLevels(newVariables);
    const statData = _.get(newVariables, 'stat_data');
    const parsed = Schema.safeParse(statData);
    pendingCompanionLevels.clear();
    pendingCompanionLibraryLevels.clear();
    if (!parsed.success) return;

    if (!_.isEqual(statData, parsed.data)) {
      _.set(newVariables, 'stat_data', parsed.data);
    }
  });

  console.info('[踏月寻仙] 独立变量守卫已启用');
}

$(() => {
  waitGlobalInitialized('Mvu')
    .then(() => installGuard())
    .catch(e => console.warn('[踏月寻仙] 独立变量守卫加载失败', e));
});

